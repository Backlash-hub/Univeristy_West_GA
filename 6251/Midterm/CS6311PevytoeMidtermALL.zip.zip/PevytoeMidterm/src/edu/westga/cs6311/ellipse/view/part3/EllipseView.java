/**
 * 
 */
package edu.westga.cs6311.ellipse.view.part3;
import java.awt.geom.Point2D;
import java.util.Scanner;
/**
 * Creating an Ellipse
 * 
 * @author William Pevytoe
 * 
 * @version 9/19/23
 */

public class EllipseView {
	private Point2D.Double ellipse;
	private double majorRadius;
	private double minorRadius;
	private double xValue;
	private double yValue;
	
	
	public EllipseView() {
		this.ellipse = new Point2D.Double();
		this.majorRadius = 0.0;
		this.minorRadius = 0.0;
		this.xValue = 0.0;
		this.yValue = 0.0;
	
	}
	
	public void inputEllipseValues() {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter the X value for the center point: ");
	    this.xValue = Double.parseDouble(input.nextLine());

	    System.out.println("Enter the Y value for the center point: ");
	    this.yValue = Double.parseDouble(input.nextLine());
	    
		System.out.println("Enter the Major Radius: ");
	    this.majorRadius = Double.parseDouble(input.nextLine());
    
	    System.out.println("Enter the Minor Radius: ");
	    this.minorRadius = Double.parseDouble(input.nextLine());
	    
	    input.close();
	}
	
	public void initializeEllipse() {
		this.ellipse = new Point2D.Double(this.xValue, this.yValue);
	}
	
	/**
	 * Prints the expected and actual values of the multiple points
	 * relating to the ellipse
	 */
	public void displayPointInformation(Point2D.Double tempEllipse, double xValue, double yValue){
		System.out.println("\tExpected x:\t" + xValue);
		System.out.println("\tActual x:\t" + tempEllipse.getX());
		System.out.println("");
		
		System.out.println("\tExpected y:\t" + yValue);
		System.out.println("\tActual y:\t" + tempEllipse.getY());
		System.out.println("");
	}
	
	/**
	 * Prints the expected and actual values of the multiple points
	 * relating to the ellipse
	 */
	public void demoEllipse() {
		System.out.println("\tHere is the center point value: " + this.ellipse);
		this.displayPointInformation(this.ellipse, this.xValue, this.yValue);
		
		System.out.println("\tActual Major Radius value:\t" + this.getMajorRadius());
		System.out.println("");
				
		System.out.println("\tActual Minor Radius value:\t" + this.getMinorRadius());
		System.out.println("");
		
		System.out.println("\tActual Top Point value:\t\t" + this.getTopPoint());
		System.out.println("");
		
		System.out.println("\tActual Right Point value:\t" + this.getRightPoint());
		System.out.println("");
		
		System.out.println("\tActual Focal Length value:\t" + this.getFocalLength());
		System.out.println("");
		
		System.out.println("\tActual Left Focus Point value:\t\t" + this.getLeftFocusPoint());
		System.out.println("");
		
		System.out.println("\tActual Right Focus Point value:\t\t" + this.getRightFocusPoint());
		System.out.println("");
		
		System.out.println("\tActual eccentricity value:\t" + this.getEccentricity());
		System.out.println("");
		
		System.out.println("\tActual Eccentricity value:\t" + this.getEccentricity());
		System.out.println("");
		
		System.out.println("\tActual first circumference value:\t" + this.getCircumference1());
		System.out.println("");
		
		System.out.println("\tActual second circumference value:\t" + this.getCircumference2());
		System.out.println("");
	}
	
	/**
	 * Returns the center point of the ellipse
	 * 
	 * @return the Point2D.Double of the ellipse center
	 */
	public Point2D.Double getCenterPoint() {
		return this.ellipse;		
	}	
	
	/**
	 * This will give the Major Radius
	 * 
	 * @return the @majorRadius
	 */
	public double getMajorRadius() {
		return this.majorRadius;
	}
	
	/**
	 * This will give the Minor Radius
	 * 
	 * @return the minorRadius value
	 */
	public double getMinorRadius() {
		return this.minorRadius;	
	}
	
		/**
	 * Will return the top coordinate of the ellipse (Center Y value + the Minor Radius value)
	 *  
	 * @return the topPoint coordinates
	 */
	public Point2D.Double getTopPoint() {
		double topYValue = this.ellipse.getY() - this.minorRadius;
		return new Point2D.Double(this.ellipse.getX(), topYValue);
	}
	
	/**
	 * Will return the right coordinate of the ellipse (Center X value + the Major Radius value)
	 * 
	 * @return the right point coordinates
	 */
	public Point2D.Double getRightPoint() {
		double rightXValue = this.ellipse.getX() + this.majorRadius; 
		return new Point2D.Double(rightXValue, this.ellipse.getY());		
	}
	
	/**
	 * Will return the focal length (two points on the Major axis and their distance from the center point) 
	 * 
	 * focal length = √ (major radius2 – minor radius2) 
	 * 
	 * @return the focal length
	 */
	public double getFocalLength() {
		return Math.sqrt(Math.pow(this.majorRadius, 2) - Math.pow(this.minorRadius, 2));
	}
	
	/**
	 * Will return the left focal coordinates (Center X value - the FocalLength value)
	 * 
	 * @return the left focus point coordinates 
	 */
	public Point2D.Double getLeftFocusPoint() {
		double leftFoucsValue = this.ellipse.getX() - this.getFocalLength();
		return new Point2D.Double(leftFoucsValue, this.ellipse.getY()); 
	}
	
	/**
	 * Will return the right focal coordinates (Center X value + the FocalLength value)
	 * 
	 * @return the right focus point coordinates
	 */
	public Point2D.Double getRightFocusPoint() {
		double rightFocusValue = this.ellipse.getX() + this.getFocalLength();
		return new Point2D.Double(rightFocusValue, this.ellipse.getY());
	}
	
	/**
	 * Will return the eccentricity of the ellipse (focal length / major radius)
	 * 
	 * @return the eccentricity of the ellipse
	 */
	public double getEccentricity() {
		return this.getFocalLength() / this.getMajorRadius();
	}
	
	/**
	 * First formula to approximate the circumference of the ellipse
	 * 
	 * @return the approximate circumference of ellipse
	 */
	public double getCircumference1() {
		double value1 = Math.sqrt((10 * this.majorRadius * this.minorRadius) +  
				3 * ((this.majorRadius * this.majorRadius) + (this.minorRadius * this.minorRadius)));
		
		return Math.PI * ((3 * (this.majorRadius + this.minorRadius)) - value1);
	}
	
	/**
	 * Second formula to approximate the circumference of the ellipse
	 * 
	 * @return the approximate circumference of ellipse
	 */
	public double getCircumference2() {
		double h = Math.pow(this.majorRadius - this.minorRadius, 2) / Math.pow(this.majorRadius + this.minorRadius, 2);
		return Math.PI * (this.majorRadius + this.minorRadius) * (1 + (3 * h) / (10 + Math.sqrt(4 - 3 * h)));
	}
}
