/**
 * 
 */
package edu.westga.cs6311.ellipse.controller.test;


/**
 * Testing the EllipseDemo
 * 
 * @author William Pevytoe
 * 
 * @version 9/19/23
 */
public class TestDriver {

	/**
	 * Entry point for the program.  It creates the EllipseDemo
	 * 	and calls its test methods
	 * 
	 * @param	args	Not used
	 */
	public static void main(String[] args) {
		EllipseDemo demo1 = new EllipseDemo();
		demo1.testEllipsePart01();
		demo1.testEllipsePart02();
	}

}
