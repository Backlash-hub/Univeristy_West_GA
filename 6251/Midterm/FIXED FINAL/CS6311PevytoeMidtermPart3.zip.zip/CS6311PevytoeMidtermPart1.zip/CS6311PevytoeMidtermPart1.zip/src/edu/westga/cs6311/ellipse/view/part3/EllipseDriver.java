/**
 * 
 */
package edu.westga.cs6311.ellipse.view.part3;

/**
 * Creating an Ellipse
 * 
 * @author William Pevytoe
 * 
 * @version 9/19/23
 */

public class EllipseDriver {
	/**
	 * Entry point for the program.  It creates the EllipseView
	 * 	and calls its test methods
	 * 
	 * @param	args	Not used
	 */
	
	public static void main(String[] args) {
		EllipseView demo1 = new EllipseView();
		demo1.inputEllipseValues();
		demo1.initializeEllipse();
		demo1.demoEllipse();
	}
}
