/**
 * 
 */
package edu.westga.cs6311.ellipse.controller.test;

//import edu.westga.cs6311.ellipse.model.*;
import java.awt.geom.Point2D;

import edu.westga.cs6311.ellipse.model.Ellipse;

/**
 * Creating an Ellipse
 * 
 * @author William Pevytoe
 * 
 * @version 9/19/23
 */
public class EllipseDemo {
	private Ellipse theEllipse;
	private Point2D.Double ellipse;
	private double majorRadius;
	private double minorRadius;

	

	/**
	 * Creates a new EllipseDemo object
	 */
	public EllipseDemo() {
		this.majorRadius = 8.0;
		this.minorRadius = 4.0;
		this.ellipse = new Point2D.Double(10.0, 8.4);
		this.theEllipse = new Ellipse(this.ellipse, this.majorRadius, this.minorRadius);
		
	}


	/**
	 * Prints the expected and actual values of the multiple points
	 * relating to the ellipse
	 */
	public void displayPointInformation(Point2D.Double center, double xValue, double yValue){
		System.out.println("\tExpected x:\t" + xValue);
		System.out.println("\tActual x:\t" + center.getX());
		System.out.println("");
		
		System.out.println("\tExpected y:\t" + yValue);
		System.out.println("\tActual y:\t" + center.getY());
		System.out.println("");
	}
	
	/**
	 * Prints the expected and actual values of the multiple points
	 * relating to the ellipse
	 */
	public void testEllipsePart01() {
		Point2D.Double center = this.theEllipse.getCenterPoint();
		System.out.println("\tHere is the center point value: " + center);
		this.displayPointInformation(center, 10.0, 8.4);
		
		System.out.println("\tExpected Major Radius value:\t" + 8.0);
		System.out.println("\tActual Major Radius value:\t" + this.theEllipse.getMajorRadius());
		System.out.println("");
				
		System.out.println("\tExpected Minor Radius value:\t" + 4.0);
		System.out.println("\tActual Minor Radius value:\t" + this.theEllipse.getMinorRadius());
		System.out.println("");
		
		System.out.println("\tExpected Top Point value:\tPoint2D.Double[10.0, 4.4]");
		System.out.println("\tActual Top Point value:\t\t" + this.theEllipse.getTopPoint());
		System.out.println("");
		
		System.out.println("\tExpected Right Point value:\tPoint2D.Double[18.0, 8.4]");
		System.out.println("\tActual Right Point value:\t" + this.theEllipse.getRightPoint());
		System.out.println("");
		
		System.out.println("\tExpected Focal Length value:\t" + 6.928203230275509);
		System.out.println("\tActual Focal Length value:\t" + this.theEllipse.getFocalLength());
		System.out.println("");
		
		System.out.println("\tExpected Left Focus Point value:\tPoint2D.Double[3.0717967697244912, 8.4]");
		System.out.println("\tActual Left Focus Point value:\t\t" + this.theEllipse.getLeftFocusPoint());
		System.out.println("");
		
		System.out.println("\tExpected Right Focus Point value:\tPoint2D.Double[16.928203230275507, 8.4]");
		System.out.println("\tActual Right Focus Point value:\t\t" + this.theEllipse.getRightFocusPoint());
		System.out.println("");
	}
	/**
	 * Prints the expected and actual values of the multiple points
	 * relating to the ellipse
	 */
	public void testEllipsePart02() {
		Point2D.Double center = this.theEllipse.getCenterPoint();
		System.out.println("\tHere is the center point value: " + center);
		this.displayPointInformation(center, 10.0, 8.4);
		
		System.out.println("\tExpected Eccentricity value:\t0.8660254037844386");
		System.out.println("\tActual Eccentricity value:\t" + this.theEllipse.getEccentricity());
		System.out.println("");
		
		System.out.println("\tExpected first circumference value:\t38.75368439068515");
		System.out.println("\tActual first circumference value:\t" + this.theEllipse.getCircumference1());
		System.out.println("");
		
		System.out.println("\tExpected second circumference value:\t38.75379286452034");
		System.out.println("\tActual second circumference value:\t" + this.theEllipse.getCircumference2());
		System.out.println("");
	
	}
}

	