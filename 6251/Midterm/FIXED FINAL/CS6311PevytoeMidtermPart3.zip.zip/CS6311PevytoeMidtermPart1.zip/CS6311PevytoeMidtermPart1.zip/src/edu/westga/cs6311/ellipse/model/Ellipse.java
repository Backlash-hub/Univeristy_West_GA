package edu.westga.cs6311.ellipse.model;

import java.awt.geom.Point2D;

public class Ellipse {
	private Point2D.Double ellipse;
	private double majorRadius;
	private double minorRadius;
	
	/**
	 * Creates the new Ellipse utilizing a center point,
	 * a major radius, and a minor radius.
	 * 	
	 * @param tempEllipse the center point coordinates 
	 * @param tempMajorRadius the major radius value
	 * @param tempMinorRadius the minor radius value
	 */
	public Ellipse(Point2D.Double tempEllipse, double tempMajorRadius, double tempMinorRadius) {
		this.ellipse = tempEllipse;
		this.majorRadius = tempMajorRadius;
		this.minorRadius = tempMinorRadius;
	}
	
	/**
	 * Returns the center point of the ellipse
	 * 
	 * @return the Point2D.Double of the ellipse center
	 */
	public Point2D.Double getCenterPoint() {
		return this.ellipse;		
	}
	
		/**
	 * This will give the Major Radius
	 * 
	 * @return the @majorRadius
	 */
	public double getMajorRadius() {
		return this.majorRadius;
	}
	
	/**
	 * This will give the Minor Radius
	 * 
	 * @return the minorRadius value
	 */
	public double getMinorRadius() {
		return this.minorRadius;	
	}
	
	/**
	 * Will return the top coordinate of the ellipse (Center Y value + the Minor Radius value)
	 *  
	 * @return the topPoint coordinates
	 */
	public Point2D.Double getTopPoint() {
		double topYValue = this.ellipse.getY() - this.minorRadius;
		return new Point2D.Double(this.ellipse.getX(), topYValue);
	}
	
	/**
	 * Will return the right coordinate of the ellipse (Center X value + the Major Radius value)
	 * 
	 * @return the right point coordinates
	 */
	public Point2D.Double getRightPoint() {
		double rightXValue = this.ellipse.getX() + this.majorRadius; 
		return new Point2D.Double(rightXValue, this.ellipse.getY());		
	}
	
	/**
	 * Will return the focal length (two points on the Major axis and their distance from the center point) 
	 * 
	 * focal length = √ (major radius2 – minor radius2) 
	 * 
	 * @return the focal length
	 */
	public double getFocalLength() {
		return Math.sqrt(Math.pow(this.majorRadius, 2) - Math.pow(this.minorRadius, 2));
	}
	
	/**
	 * Will return the left focal coordinates (Center X value - the FocalLength value)
	 * 
	 * @return the left focus point coordinates 
	 */
	public Point2D.Double getLeftFocusPoint() {
		double leftFoucsValue = this.ellipse.getX() - this.getFocalLength();
		return new Point2D.Double(leftFoucsValue, this.ellipse.getY()); 
	}
	
	/**
	 * Will return the right focal coordinates (Center X value + the FocalLength value)
	 * 
	 * @return the right focus point coordinates
	 */
	public Point2D.Double getRightFocusPoint() {
		double rightFocusValue = this.ellipse.getX() + this.getFocalLength();
		return new Point2D.Double(rightFocusValue, this.ellipse.getY());
	}
	/**
	 * Will return the eccentricity of the ellipse (focal length / major radius)
	 * 
	 * @return the eccentricity of the ellipse
	 */
	public double getEccentricity() {
		return this.getFocalLength() / this.getMajorRadius();
	}

	/**
	 * First formula to approximate the circumference of the ellipse
	 * 
	 * @return the approximate circumference of ellipse
	 */
	public double getCircumference1() {
		double value1 = Math.sqrt((10 * this.majorRadius * this.minorRadius) +  
				3 * ((this.majorRadius * this.majorRadius) + (this.minorRadius * this.minorRadius)));
		
		return Math.PI * ((3 * (this.majorRadius + this.minorRadius)) - value1);
	}

	/**
	 * Second formula to approximate the circumference of the ellipse
	 * 
	 * @return the approximate circumference of ellipse
	 */
	public double getCircumference2() {
		double h = Math.pow(this.majorRadius - this.minorRadius, 2) / Math.pow(this.majorRadius + this.minorRadius, 2);
		return Math.PI * (this.majorRadius + this.minorRadius) * (1 + (3 * h) / (10 + Math.sqrt(4 - 3 * h)));
	}
}