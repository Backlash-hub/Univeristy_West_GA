/**
 * 
 */
package edu.westga.cs6311.ellipse.model;
import java.awt.geom.Point2D;



/**
 * Creating an Ellipse
 * 
 * @author William Pevytoe
 * 
 * @version 9/19/23
 */
public class EllipseDemo {
	private Point2D.Double ellipse;
	private double majorRadius;
	private double minorRadius;
	
	/**
	 * Creates the new Ellipse utilizing a center point,
	 * a major radius, and a minor radius.
	 * 	
	 * @param tempEllipse the center point coordinates 
	 * @param tempMajorRadius the major radius value
	 * @param tempMinorRadius the minor radius value
	 */
	public EllipseDemo(Point2D.Double tempEllipse, double tempMajorRadius, double tempMinorRadius) {
		this.ellipse = tempEllipse;
		this.majorRadius = tempMajorRadius;
		this.minorRadius = tempMinorRadius;
	}
	
	/**
	 * Returns the center point of the ellipse
	 * 
	 * @return the Point2D.Double of the ellipse center
	 */
	public Point2D.Double getCenterPoint() {
		return this.ellipse;		
	}
	
	/**
	 * Prints the expected and actual values of the multiple points
	 * relating to the ellipse
	 */
	public void testEllipsePart01() {
		Point2D.Double center = this.getCenterPoint();
		System.out.println("\tHere is the center point value: " + center);
		this.displayPointInformation(center, 10.0, 8.4);
		
		System.out.println("\tExpected Major Radius value:\t" + 8.0);
		System.out.println("\tActual Major Radius value:\t" + this.getMajorRadius());
		System.out.println("");
				
		System.out.println("\tExpected Minor Radius value:\t" + 4.0);
		System.out.println("\tActual Minor Radius value:\t" + this.getMinorRadius());
		System.out.println("");
		
		System.out.println("\tExpected Top Point value:\tPoint2D.Double[10.0, 4.4]");
		System.out.println("\tActual Top Point value:\t\t" + this.getTopPoint());
		System.out.println("");
		
		System.out.println("\tExpected Right Point value:\tPoint2D.Double[18.0, 8.4]");
		System.out.println("\tActual Right Point value:\t" + this.getRightPoint());
		System.out.println("");
		
		System.out.println("\tExpected Focal Length value:\t" + 6.928203230275509);
		System.out.println("\tActual Focal Length value:\t" + this.getFocalLength());
		System.out.println("");
		
		System.out.println("\tExpected Left Focus Point value:\tPoint2D.Double[3.0717967697244912, 8.4]");
		System.out.println("\tActual Left Focus Point value:\t\t" + this.getLeftFocusPoint());
		System.out.println("");
		
		System.out.println("\tExpected Right Focus Point value:\tPoint2D.Double[16.928203230275507, 8.4]");
		System.out.println("\tActual Right Focus Point value:\t\t" + this.getRightFocusPoint());
		System.out.println("");
	}
	
	/**
	 * Prints the expected and actual values of the multiple points
	 * relating to the ellipse
	 */
	
	
	/**
	 * Prints the expected and actual values of the multiple points
	 * relating to the ellipse
	 */
	public void displayPointInformation(Point2D.Double center, double xValue, double yValue){
		System.out.println("\tExpected x:\t" + xValue);
		System.out.println("\tActual x:\t" + center.getX());
		System.out.println("");
		
		System.out.println("\tExpected y:\t" + yValue);
		System.out.println("\tActual y:\t" + center.getY());
		System.out.println("");
	}
	
	
	/**
	 * This will give the Major Radius
	 * 
	 * @return the @majorRadius
	 */
	public double getMajorRadius() {
		return this.majorRadius;
	}
	
	/**
	 * This will give the Minor Radius
	 * 
	 * @return the minorRadius value
	 */
	public double getMinorRadius() {
		return this.minorRadius;	
	}
	
	/**
	 * Will return the top coordinate of the ellipse (Center Y value + the Minor Radius value)
	 *  
	 * @return the topPoint coordinates
	 */
	public Point2D.Double getTopPoint() {
		double topYValue = this.ellipse.getY() - this.minorRadius;
		return new Point2D.Double(this.ellipse.getX(), topYValue);
	}
	
	/**
	 * Will return the right coordinate of the ellipse (Center X value + the Major Radius value)
	 * 
	 * @return the right point coordinates
	 */
	public Point2D.Double getRightPoint() {
		double rightXValue = this.ellipse.getX() + this.majorRadius; 
		return new Point2D.Double(rightXValue, this.ellipse.getY());		
	}
	
	/**
	 * Will return the focal length (two points on the Major axis and their distance from the center point) 
	 * 
	 * focal length = √ (major radius2 – minor radius2) 
	 * 
	 * @return the focal length
	 */
	public double getFocalLength() {
		return Math.sqrt(Math.pow(this.majorRadius, 2) - Math.pow(this.minorRadius, 2));
	}
	
	/**
	 * Will return the left focal coordinates (Center X value - the FocalLength value)
	 * 
	 * @return the left focus point coordinates 
	 */
	public Point2D.Double getLeftFocusPoint() {
		double leftFoucsValue = this.ellipse.getX() - this.getFocalLength();
		return new Point2D.Double(leftFoucsValue, this.ellipse.getY()); 
	}
	
	/**
	 * Will return the right focal coordinates (Center X value + the FocalLength value)
	 * 
	 * @return the right focus point coordinates
	 */
	public Point2D.Double getRightFocusPoint() {
		double rightFocusValue = this.ellipse.getX() + this.getFocalLength();
		return new Point2D.Double(rightFocusValue, this.ellipse.getY());
	}
}
	
	
