/**
 * 
 */
package edu.westga.cs6311.ellipse.model;
import java.awt.geom.Point2D;


/**
 * Testing the EllipseDemo
 * 
 * @author William Pevytoe
 * 
 * @version 9/19/23
 */
public class TestDriver {

	/**
	 * Entry point for the program.  It creates the EllipseDemo
	 * 	and calls its test methods
	 * 
	 * @param	args	Not used
	 */
	public static void main(String[] args) {
		Point2D.Double tempEllipse = new Point2D.Double(10.0, 8.4);
		double majorRadius = 8.0;
		double minorRadius = 4.0;
		EllipseDemo demo1 = new EllipseDemo(tempEllipse, majorRadius, minorRadius);
		demo1.testEllipsePart01();
	}

}
