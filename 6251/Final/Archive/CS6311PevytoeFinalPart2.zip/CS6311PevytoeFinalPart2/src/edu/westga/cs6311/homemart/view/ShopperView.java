package edu.westga.cs6311.homemart.view;

import java.util.ArrayList;
import java.util.Scanner;

import edu.westga.cs6311.homemart.model.Inventory;
import edu.westga.cs6311.homemart.model.InventoryItem;
import edu.westga.cs6311.homemart.model.Shopper;

/**
 *The Shopper UI and Shopper info
 * 
 * @author William Pevytoe
 * 
 * @version 12/2/23
 */
public class ShopperView {
	private Scanner input;
	private Inventory theInventory;
	private Shopper theShopper;
	
	/**
	 * Constructs the User inputs and Inventory
	 * 
	 * @param item is theInventory objects
	 */
	public ShopperView(Inventory item) {
		this.input = new Scanner(System.in);
		this.theInventory = item;
	}
	
	/**
	 * Runs the program
	 */
	public void runShopper() {
		int numSelection = 0;
		System.out.println("Welcome to the Shopper Application\n");
		this.getShopperInformation();
		while (numSelection != 6) {
			this.displayMenu();
			System.out.println(" Enter your choice: ");
			String userSelection = this.input.next();
			numSelection = Integer.parseInt(userSelection);
			if (numSelection == 1) {
				this.viewInventory();
			} else if (numSelection == 2) {
				this.addNewItem();
			} else if (numSelection == 3) {
				this.viewCart();
			} else if (numSelection == 4) {
				this.viewRemainingBudget();
			} else if (numSelection == 5) {
				this.checkout();
			} else if (numSelection != 6) {			
				System.out.println("That's not a valid choice.  Please try again\n");
			}
		}
		System.out.println("Thank you for using the shopper application.\n");		
	}
	
	private void getShopperInformation() {
		String name = "";
		Double budget = 0.0;
		while (name.isEmpty()) {
			System.out.println("Please enter your name: ");
			name = this.input.next();
		}
		while (budget <= 0) {
			System.out.println("Please  enter the amount you have to spend:  ");
			budget = this.input.nextDouble();
		}
		this.theShopper = new Shopper(name, budget);
		System.out.println("Welcome " + name + ". " + "Enjoy spending your " + String.format("$%6.2f", budget));	
	}
	
	private void displayMenu() {
		System.out.println("\n1 ‐ View inventory");
		System.out.println("2 ‐ Add item to the cart");
		System.out.println("3 ‐ View cart");
		System.out.println("4 ‐ View money remaining");
		System.out.println("5 ‐ Checkout");
		System.out.println("6 ‐ Quit shopper application\n");
	}
	
	private void viewInventory() {
		System.out.println(this.theInventory.toString());
	}
	
	private void addNewItem() {
		String name = "";
		int quantity = 0;
		while (name.isEmpty()) {
			System.out.println("\nEnter item name to be purchased: ");
			name = this.input.next();
			if (this.theInventory.findItem(name) == null) {
				System.out.println("That item does not exist");
				return;
			}
		}
		while (quantity <= 0) {
			System.out.println("Enter the number of " + name + "(s) to buy: ");
			quantity = this.input.nextInt();
			if (this.theInventory.findItem(name).getItemQuantity() < quantity) {
				System.out.println("There are not enough " + name + "(s) in the inventory.");
				return;
			}
		}
		
		InventoryItem item = this.theInventory.findItem(name);
		
		if (this.theShopper.haveEnoughToBuy(item, quantity)) {
			this.theShopper.addItem(item, quantity);
			System.out.println("You have added " + quantity + " " + name + "(s) to your cart");
			System.out.println("You have " + String.format("$%6.2f", this.theShopper.getBudget()) + " remaining to spend.");
			} else {
				System.out.println("You don't have enough money to purchase " + quantity + " " + name + "(s).");
			}
	}
	
	private void viewCart() {
		ArrayList<InventoryItem> cartItems = this.theShopper.getTheCart();
		if (cartItems.isEmpty()) {
			System.out.println("\nNo items in Cart");
			
		} else {
			for (InventoryItem item : cartItems) {
				System.out.println("\n" + item);
			}
		}
		
	}
	
	private void viewRemainingBudget() {
		System.out.println("\nAmount remaining to spend: " + String.format("$%6.2f", this.theShopper.getBudget()));
	}
	
	private void checkout() {
		this.theShopper.purchaseCart();
		System.out.println("\nYour purchase has been completed.");
	}

}
