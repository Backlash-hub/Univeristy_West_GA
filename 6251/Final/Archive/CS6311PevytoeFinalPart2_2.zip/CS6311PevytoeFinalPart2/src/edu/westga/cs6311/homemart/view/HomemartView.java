package edu.westga.cs6311.homemart.view;

import java.util.Scanner;

import edu.westga.cs6311.homemart.model.Inventory;

/**
 *The user UI and user info
 * 
 * @author William Pevytoe
 * 
 * @version 12/2/23
 */
public class HomemartView {
	private Scanner userInput;
	private Inventory theInventory;
	
	/**
	 * Constructs the User inputs and Inventory
	 * 
	 * @param item is theCart objects
	 */
	public HomemartView(Inventory item) {
		this.userInput = new Scanner(System.in);
		this.theInventory = item;
	}
	
	/**
	 * Runs the program
	 */
	public void runHomemart() {
		int numSelection = 0;
		System.out.println("Welcome to the Homemart Application");
		while (numSelection != 3) {
			this.displayMenu();
			System.out.println("Enter your choice: ");
			numSelection = Integer.parseInt(this.userInput.next());
			if (numSelection == 1) {
				this.managerApp();
			} else if (numSelection == 2) {
				this.shopperApp();
			} else if (numSelection != 3) {
				System.out.println("That's not a valid choice.  Please try again\n");
			}
		}
		System.out.println("Thank you for using the Homemart application.  Have a nice day.");
	}
	
	private void displayMenu() {
		System.out.println("\n1 ‐ Start manager application");
		System.out.println("2 ‐ Start shopper application");
		System.out.println("3 ‐ Quit\n");
	}
	
	private void managerApp() {
		ManagerView managerView = new ManagerView(this.theInventory);
		managerView.runManager();
	}
	
	private void shopperApp() {
		ShopperView shopperview = new ShopperView(this.theInventory);
		shopperview.runShopper();
	}
}
