/**
 * 
 */
package edu.westga.cs6311.shapes;

/**
 * This class will create variables to store information about a rectangle
 * (width and height) and calculate the perimeter. 
 * 
 * @author William Pevytoe
 * @version 8/16/2023
 * 
 */
public class RectanglePerimeterTester {
	//This is the class to calculate the parimeter of a rectangle
	
	public static void main(String[] args) {
		//TODO Change the width variable's initialization to store 20
		double width = 20;
		
		//TODO Change the height variable's initialization to store 40
		double height = 40;
		
		//TODO Declare a variable named perimeter and initialize that variable
		//		to hold the product of the 2 * (width + height)
		double perimeter = 2 *(width + height);

		System.out.println("Expected Perimeter: 120.0");
		
		System.out.println("Calculated perimeter: " + perimeter);

	}

}
