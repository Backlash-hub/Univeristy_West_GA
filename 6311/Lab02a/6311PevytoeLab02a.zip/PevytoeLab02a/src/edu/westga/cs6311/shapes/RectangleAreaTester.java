package edu.westga.cs6311.shapes;

/**
 * This class will create variables to store information about a rectangle
 * (width and height) and calculate the area
 * 
 * @author William Pevytoe
 * @version 8/16/2023
 *
 */
public class RectangleAreaTester {
	public static void main(String [] args) {
		//TODO Change the width variable's initialization to store 40
		double width = 40;
		
		//TODO Change the height variable's initialization to store 60
		double height = 60;
		
		//TODO Declare a variable named area and initialize that variable
		//		to hold the product of the width and height
		double area = width * height;
		
		System.out.println("Expected area: 2400.0");
		
		//TODO Change the 2nd println statement below to display the value
		//		of the variable that's currently storing the area
		System.out.println("Calculated area: " + area);
	}

}
