/**
 * 
 */
package edu.westga.cs6311.shapes;

/**
 * This class will create variables to store information about a cylinder
 * (radius, height, PI) and calculate the Volume. 
 * 
 * @author William Pevytoe
 * @version 8/16/2023
 * 
 */
public class CylinderVolumeTester {
	// This is the class to calculate the Volume of a cylinder
	
	public static void main(String[] args) {
		//TODO Change the width variable's initialization to store 15
		double radius = 15;
				
		//TODO Change the height variable's initialization to store 40
		double height = 40;
		
		//PI is a constant
		final double PI = 3.1415926535898;
		
		//TODO Declare a variable named volume and initialize that variable
		//		to hold the product of the PI * radius * height
		double volume = PI * height * Math.pow(radius, 2);
		
		System.out.println("Expected Volume: 28274.3338823082");
		
		System.out.println("Calculated Volume: " + volume);

	}

}
