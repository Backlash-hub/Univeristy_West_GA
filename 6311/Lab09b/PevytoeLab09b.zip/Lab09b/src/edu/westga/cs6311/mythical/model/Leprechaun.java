package edu.westga.cs6311.mythical.model;

/**
 * Leprechaun finding treasure and sharing it with everyone.
 * 
 * @author William Pevytoe
 * 
 * @version 9/9/2023
 */
public class Leprechaun {
	private Treasure theTreasure;
	private double initialValue;
	private double totalValue;
	
	/**
	 * Sets the initial Value of the Leperchaun's treasure.
	 * 
	 * @param initialInput is the initial value of the treasure.
	 */
	public Leprechaun(double initialInput) {
		this.initialValue = initialInput;
		this.totalValue = this.initialValue;
	}

	/**
	 * Leprechaun finds treasure and removes it from the container.
	 * 
	 * @param newTreasure is a type of Treasure.
	 */
	public void findTreasure(Treasure newTreasure) {
		this.theTreasure = newTreasure;
		this.totalValue += this.theTreasure.emptyTreasureBucket();
	}

	/**
	 * Every time the Leprechaun meets a person, the Leprechaun gives away 27% of the treasure they currently hold.  
	 */
	public void meetPerson() {
		this.totalValue -= (this.totalValue * .27);
	}

	/**
	 * The total value of the Treasure the Leprechaun has.
	 * 
	 * @return the @totalValue of what the Leprechaun has in their possession.  
	 */
	public double getAssetValue() {
		return this.totalValue;
	}
	
	/**
	 * The standard Leprechaun greeting string.
	 * 
	 * @return the greeting string
	 */
	public String getGreeting() {
		return "Top o' the mornin to ya!";
	}
}