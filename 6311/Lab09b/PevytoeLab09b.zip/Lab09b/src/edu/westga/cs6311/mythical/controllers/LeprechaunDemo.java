package edu.westga.cs6311.mythical.controllers;

import java.text.NumberFormat;

import edu.westga.cs6311.mythical.model.Leprechaun;
import edu.westga.cs6311.mythical.model.Treasure;

/**
 * This is the driver for the informal test application
 * 
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * ~~ DO NOT MODIFY THE CODE INSIDE TestDriver ~~
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * 
 * @author	CS6311
 * @version	Fall 2023
 *
 */
public class LeprechaunDemo {
	private Treasure treasurePail;
	private Treasure treasureChest;
	private Leprechaun patti;
	private NumberFormat currencyFormatter;

	/**
	 * Creates a new LeprechaunDemo object with 2 Treasure
	 * 	objects and an instance of a Leprechaun
	 */
	public LeprechaunDemo() {
		this.treasurePail = new Treasure(48);
		this.treasureChest = new Treasure(250);
		this.patti = new Leprechaun(100.0);
		this.currencyFormatter = NumberFormat.getCurrencyInstance();
	}
	
	/**
	 * Runs a set of tests for the Leprechaun's behavior
	 */
	public void testLeprechaun() {
		this.describeLeprechaun("Patti's initial value", 100.00);
		
		System.out.println("Patti says:");
		System.out.println("\tExpected:\t\"Top o' the mornin to ya!\"");
		System.out.println("\tActual:\t\t\"" + this.patti.getGreeting() + "\"");
		System.out.println();
		
		this.patti.findTreasure(this.treasurePail);
		this.describeLeprechaun("Patti's value after finding the small treasure", 12847.84);
		System.out.println("Small treasure's value after being found:");
		System.out.println("\tExpected:\t$0.00");
		System.out.println("\tActual:\t\t" + this.currencyFormatter.format(this.treasurePail.getValue()));
		System.out.println();
		
		this.patti.meetPerson();
		this.describeLeprechaun("Patti's value after giving away first time", 9378.9232);
		
		this.patti.meetPerson();
		this.describeLeprechaun("Patti's value after giving away second time", 6846.613936);
		
		this.patti.findTreasure(this.treasureChest);
		this.describeLeprechaun("Patti's value after finding the large treasure", 73241.61394);
		System.out.println("Large treasure's value after being found:");
		System.out.println("\tExpected:\t$0.00");
		System.out.println("\tActual:\t\t" + this.currencyFormatter.format(this.treasureChest.getValue()));
	}
	
	/**
	 * Helper method that accepts a message and the expected value
	 * 
	 * @param	message			The message to be displayed
	 * @param	expectedValue	The expected value
	 */
	public void describeLeprechaun(String message, double expectedValue) {
		System.out.println(message);
		System.out.println("\tExpected: \t" + this.currencyFormatter.format(expectedValue));
		System.out.println("\tActual: \t" + this.currencyFormatter.format(this.patti.getAssetValue()));
		System.out.println();
	}
}
