package edu.westga.cs6311.mythical.controllers;

/**
 * This is the driver for the informal test application
 * 
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * ~~ DO NOT MODIFY THE CODE INSIDE TestDriver ~~
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * 
 * @author	CS6311
 * @version	Fall 2023
 *
 */
public class TestDriver {
	/**
	 * Entry point for the program.  It creates TreasureDemo
	 * 	and LeprechaunDemo instances and calls their test methods
	 * 
	 * @param	args	Not used
	 */
	public static void main(String [] args) {
		System.out.println("VVVVVVVV Treasure tests VVVVVVVV");
		System.out.println();
		TreasureDemo demo1 = new TreasureDemo();
		demo1.testTreasure();
		
		System.out.println();
		System.out.println("----------------------------------");
		System.out.println("VVVVVVVV Leprechaun tests VVVVVVVV");
		System.out.println();
		LeprechaunDemo demo2 = new LeprechaunDemo();
		demo2.testLeprechaun();
		
	}
}
