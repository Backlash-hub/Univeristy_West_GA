package edu.westga.cs6311.mythical.controllers;

import java.text.NumberFormat;

import edu.westga.cs6311.mythical.model.Treasure;

/**
 * This class is used to informally test the Treasure class.
 * 	NOTE: This class won't compile until the Treasure class
 * 	has been completed correctly
 * 
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * ~~ DO NOT MODIFY THE CODE INSIDE TreasureDemo ~~
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * 
 * @author	CS6311
 * @version	Fall 2023
 *
 */
public class TreasureDemo {
	private Treasure largeTreasure;
	private Treasure smallTreasure;
	private NumberFormat currencyFormatter;	
	
	/**
	 * Creates a new TreasureDemo object with 2 Treasures
	 */
	public TreasureDemo() {
		this.largeTreasure = new Treasure(105);
		this.smallTreasure = new Treasure(10);
		this.currencyFormatter = NumberFormat.getCurrencyInstance();
	}
	
	/**
	 * This method will print information about each Treasure,
	 * 	have each Treasure be claimed, and print information 
	 * 	about each (newly found) Treasure
	 */
	public void testTreasure() {
		this.describeTreasure2("New large treasure", this.largeTreasure, 105, 27885.9);
		
		this.describeTreasure2("New small treasure", this.smallTreasure, 10, 2655.8);
		
		System.out.println();
		System.out.println("~~~~ The treasures get found ~~~~");
		this.largeTreasure.getsFound();
		this.smallTreasure.getsFound();
		
		System.out.println();
		this.describeTreasure2("Found large treasure", this.largeTreasure, 0, 0.0);
		
		this.describeTreasure2("Found small treasure", this.smallTreasure, 0, 0.0);
		System.out.println();
	}
	
	/**
	 * Helper method that accepts a message and the expected value
	 * 
	 * @param	message			The message to be displayed
	 * @param	theTreasure		The treasure to be described
	 * @param	expectedWeight	The treasure's expected weight
	 * @param	expectedValue	The treasure's expected value
	 */
	public void describeTreasure2(String message, Treasure theTreasure, 
			int expectedWeight, double expectedValue) {
		System.out.println(message);
		System.out.println("\tExpected weight: \t" + expectedWeight);
		System.out.println("\tActual weight: \t\t" + theTreasure.getWeight());	
		
		System.out.println("\tExpected value: \t" + this.currencyFormatter.format(expectedValue));
		System.out.println("\tActual value: \t\t" + this.currencyFormatter.format(theTreasure.getValue()));
		System.out.println();
	}
}
