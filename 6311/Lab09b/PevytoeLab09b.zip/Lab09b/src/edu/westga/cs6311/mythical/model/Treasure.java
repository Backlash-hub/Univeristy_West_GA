package edu.westga.cs6311.mythical.model;

import java.text.NumberFormat;

/**
 * Finding Treasure 
 * @author William Pevytoe
 * @version 9/8/2023
 */
public class Treasure {
	private int platinumDollarValue;
	private int goldDollarValue;
	private int silverDollarValue;
	private int platinumPercent;
	private int goldPercent;
	private int silverPercent;
	private int totalOunces;
	private double totalValue;
	private float platinumOunces;
	private float goldOunces;
	private float silverOunces;
	private NumberFormat currencyFormatter;	
	
	/**
	 * Sets the values of the Treasure composition per ounce
	 * 
	 * Sets the percentages of Treasure composition 
	 * 
	 * Allow for currency formatter
	 * 
	 * @param ouncesOfTreasure local variable that will be the @totalOunces
	 */
	public Treasure(int ouncesOfTreasure) {
		this.platinumDollarValue = 1000;
		this.goldDollarValue = 1500;
		this.silverDollarValue = 19;
		this.platinumPercent = 4;
		this.goldPercent = 14;
		this.silverPercent = 82;
		this.totalOunces = ouncesOfTreasure;
		this.currencyFormatter = NumberFormat.getCurrencyInstance();
	}
	
	private void setTreasureValues() {
		this.platinumOunces = (this.platinumPercent / 100f) * (float) this.totalOunces;
		this.goldOunces = ((this.goldPercent / 100f) * (float) this.totalOunces);
		this.silverOunces = ((this.silverPercent / 100f) * (float) this.totalOunces);
		
		this.totalValue = (this.platinumOunces * this.platinumDollarValue); 
		this.totalValue += (this.goldOunces * this.goldDollarValue);
		this.totalValue	+= (this.silverOunces * this.silverDollarValue);

	}
	
	/**
	 * Will return with the actual weight of the Treasure
	 * 
	 * @return the @totalOunces
	 */
	public int getWeight() {
		return this.totalOunces;
	}
	
	/**
	 * This will return with the total value of the treasure based on the actual weight
	 * 
	 * @return the @totalValue
	 */
	public double getValue() {
		this.setTreasureValues();		
		return this.totalValue;
	}
	
	/**
	 * This will print the composition about the Treasure
	 * The total Ounces
	 * The total Ounces per precious metal
	 * The actual value of the treasure
	 */
	public void getsFound() {
		System.out.println("You Found " + this.totalOunces + " Ounces in treasure");  
		System.out.println("\t " + this.platinumOunces + " Ounces of platinum");
		System.out.println("\t" + this.goldOunces + " Ounces of gold");
		System.out.println("\t" + this.silverOunces + " Ounces of silver");
		System.out.println("\tTotal value is: " + this.currencyFormatter.format(this.getValue()) + "\r");
	}
	
	/**
	 * Empties the treasure container's value after all treasure was taken from it. 
	 * 
	 * @return the new current value of treasure container.
	 */
	public double emptyTreasureBucket() {
		double currentValue = this.getValue();
		this.totalOunces = 0;
		this.setTreasureValues();
		return currentValue;
	}
}
