package edu.westga.cs6311.statistics.view;

import java.util.Scanner;

import edu.westga.cs6311.statistics.model.RandomGenerator;

/**
 * The user UI and user info
 * 
 * @author William Pevytoe
 * 
 * @version 11/8/2023
 */
public class StatisticsView {
	private Scanner input;
	private RandomGenerator theGen;
	
	/**
	 * Constructs the User inputs (scanner) and the RandomGenerator
	 * 
	 * @param aNumber is theGen objects
	 */
	public StatisticsView(RandomGenerator aNumber) {
		this.input = new Scanner(System.in);
		if (aNumber == null) {
			return;
		} else {
			this.theGen = aNumber;	
		}
	}
	
	/**
	 * Runs the program
	 */
	public void run() {
		int numSelection = 0;
		int lineNumber = 0;
		System.out.println("Welcome to the Frequency Generator Application\r\n"
				+ "which will display a histogram of numbers between\r\n"
				+ "0 and 99, inclusive \r\n"
				+ "");
		
		while (numSelection <= 0 || numSelection > 2500) {
			System.out.println("Enter the number of numbers (no more than 2,500) you would like: ");
			String userSelection = this.input.nextLine();
			numSelection = Integer.parseInt(userSelection);
		}
		
		this.theGen.createNumbers(numSelection);
		
		while (lineNumber <= 0 || lineNumber > 10) {
			System.out.println("Enter the number of numbers per line (no more than 10): ");
			String userSelection = this.input.nextLine();
			lineNumber = Integer.parseInt(userSelection);
		}
		System.out.println("");
		this.displaySortedValues(lineNumber);
		System.out.println("");
		this.displayResults();
		System.out.println("");
		this.displayHistogram();
	}
	
	private void displayResults() {
		System.out.println("--The Stats of the values--\n");
		System.out.println("Minimum Value:\t" + this.theGen.getMinimum() + "\n");
		System.out.println("Maximum Value:\t" + this.theGen.getMaximum() + "\n");
		System.out.println("Average Value:\t" + this.theGen.getAverage() + "\n");
		System.out.println("Median Value:\t" + this.theGen.getMedian() + "\n");
	}
		
	
	private void displaySortedValues(int numLines) {
		System.out.println("--The sorted values--\n");
		for (int position = 0; position < this.theGen.getSortedNumbers().size(); position++) {
			System.out.printf("%-5s", this.theGen.getSortedNumbers().get(position));
			if ((position + 1) % numLines == 0 ) {
				System.out.println("\n");
			}
		}
	}
	
	private void displayHistogram() {
		int [] bucketBreakdown = this.theGen.getBucketCount();
		
		String histogram;
		histogram = "0-9:\t" + this.starLine(bucketBreakdown[0]) + "\n";
		histogram += "10-19:\t" + this.starLine(bucketBreakdown[1]) + "\n";
		histogram += "20-29:\t" + this.starLine(bucketBreakdown[2]) + "\n";
		histogram += "30-39:\t" + this.starLine(bucketBreakdown[3]) + "\n";
		histogram += "40-49:\t" + this.starLine(bucketBreakdown[4]) + "\n";
		histogram += "50-59:\t" + this.starLine(bucketBreakdown[5]) + "\n";
		histogram += "60-69:\t" + this.starLine(bucketBreakdown[6]) + "\n";
		histogram += "70-79:\t" + this.starLine(bucketBreakdown[7]) + "\n";
		histogram += "80-89:\t" + this.starLine(bucketBreakdown[8]) + "\n";
		histogram += "90-99:\t" + this.starLine(bucketBreakdown[9]) + "\n";
		
		System.out.println("--The Histogram--\n");
		System.out.println(histogram);
	}
	
	private String starLine(int number) {
		String result = "";
		
		for (int count = 0; count < number; count++) {
			result += "*";
		}
		
		return result;
	}
}	
		


