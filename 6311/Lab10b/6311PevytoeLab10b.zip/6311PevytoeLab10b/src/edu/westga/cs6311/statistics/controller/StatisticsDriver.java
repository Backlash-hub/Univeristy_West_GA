package edu.westga.cs6311.statistics.controller;

import edu.westga.cs6311.statistics.model.RandomGenerator;
import edu.westga.cs6311.statistics.view.StatisticsView;

/**
 *The Program Start
 *
 *@author William Pevytoe
 *
 *@version 11/15/23
 * 
 */
public class StatisticsDriver {

	/**
	 * Starts the program
	 * 
	 * @param args not used
	 */
	public static void main(String[] args) {
		RandomGenerator theGen = new RandomGenerator();
		StatisticsView statView = new StatisticsView(theGen);
		statView.run();
		

	}

}
