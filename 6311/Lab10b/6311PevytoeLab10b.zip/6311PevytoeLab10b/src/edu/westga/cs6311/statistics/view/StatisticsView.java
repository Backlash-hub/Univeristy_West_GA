package edu.westga.cs6311.statistics.view;

import java.util.Scanner;
import edu.westga.cs6311.statistics.model.RandomGenerator;

/**
 * The user UI and user info
 * 
 * @author William Pevytoe
 * 
 * @version 11/8/2023
 */
public class StatisticsView {
	private Scanner input;
	private RandomGenerator theGen;
	
	/**
	 * Constructs the User inputs (scanner) and the RandomGenerator
	 * 
	 * @param aNumber is theGen objects
	 */
	public StatisticsView(RandomGenerator aNumber) {
		this.input = new Scanner(System.in);
		if (aNumber == null) {
			return;
		} else {
			this.theGen = aNumber;	
		}
	}
	
	/**
	 * Runs the program
	 */
	public void run() {
		int numSelection = 2501;
		int lineNumber = 0;
		System.out.println("Welcome to the Frequency Generator Application\n"
				+ "which will display a histogram of numbers between\n"
				+ "0 and 99, inclusive\n");
		
		while (numSelection > 2500) {
			System.out.println("Enter the number of numbers (no more than 2,500) you would like: ");
			String userSelection = this.input.nextLine();
			numSelection = Integer.parseInt(userSelection);
		}
		
		this.theGen.createNumbers(numSelection);
		
		while (lineNumber <= 0 || lineNumber > 10) {
			System.out.println("Enter the number of numbers per line (no more than 10): ");
			String userSelection = this.input.nextLine();
			lineNumber = Integer.parseInt(userSelection);
		}
		System.out.println("");
		this.displaySortedValues(lineNumber);
		System.out.println("");
		this.displayResults();
		System.out.println("");
		this.displayHistogram();
	}
	
	private void displayResults() {
		System.out.println("--The Stats of the values--\n");
		System.out.println("Minimum Value:\t" + this.theGen.getMinimum() + "\n");
		System.out.println("Maximum Value:\t" + this.theGen.getMaximum() + "\n");
		System.out.println("Average Value:\t" + String.format("%.02f",this.theGen.getAverage()) + "\n");
		System.out.println("Median Value:\t" + this.theGen.getMedian() + "\n");
	}
		
	
	private void displaySortedValues(int numLines) {
		System.out.println("--The sorted values--\n");
		for (int position = 0; position < this.theGen.getSortedNumbers().size(); position++) {
			System.out.printf("%-5s", this.theGen.getSortedNumbers().get(position));
			if ((position + 1) % numLines == 0 ) {
				System.out.println("\n");
			}
		}
	}
	
	private void displayHistogram() {
		int [] bucketBreakdown = this.theGen.getBucketCount();
		String histogram = "";
		System.out.println("--The Histogram--\n");	
		for (int position = 0; position < bucketBreakdown.length; position++) {
			String current_bucket = "" + position;
			if (position == 0) {
				current_bucket = " ";
			}
			histogram += current_bucket + "0 - " + current_bucket + "9:  " + this.starLine(bucketBreakdown[position]) + "\n";
		}
		System.out.println(histogram);
	}
	
	private String starLine(int number) {
		String result = "";
		
		for (int count = 0; count < number; count++) {
			result += "*";
		}
		
		return result;
	}
}	
		


