package edu.westga.cs6311.statistics.model;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Random Number generator
 * 
 * @author William Pevytoe
 * 
 * @version 11//2023
 */
public class RandomGenerator {
	private ArrayList<Integer> theGenList;
	private static final int amountOfDefaultNums = 100;
	
	/**
	 * Constructor to caret the array list of integers
	 */
	public RandomGenerator() {
		this.theGenList = new ArrayList<Integer>();
	}
	
	/**
	 * Creates the random numbers based on the number input
	 */
	public void createNumbers(int howManyToGen) {
		//System.out.println("howManyToGen:" + howManyToGen);
		if (howManyToGen < 1) {
			this.createNumbers();
		} else {
			this.theGenList.clear();
			for (int position = 0; position < howManyToGen; position++) {
				int rand = (int)(Math.random() * 100);
				this.theGenList.add(rand);
			}
 		}
	}
	
	/**
	 * Overloaded function of createdNumbers
	 */
	public void createNumbers() {
		this.createNumbers(amountOfDefaultNums);
	}
	
	/**
	 * Gets the minimum value of the numbers created
	 * 
	 * @return current minimum value
	 * 
	 */
	public int getMinimum() {
		int current = 100;
		for (int position = 0; position < this.theGenList.size(); position++) {
			if (current > this.theGenList.get(position)) {
				current = this.theGenList.get(position);
			}
		}
		return current;
		/*
		 * The below code is the cleaner version but I wasn't sure if I could use it.
		 * return Collections.min(this.theGenList);
		 */
	}
	
	
	/**
	 * Gets the max value of the numbers created
	 * 
	 * @return current max value
	 */
	public int getMaximum() {
		int current = 0;
		for (int position = 0; position < this.theGenList.size(); position++) {
			if (current < this.theGenList.get(position)) {
				current = this.theGenList.get(position);
			}
		}
		return current;
		/*
		 * The below code is the cleaner version but I wasn't sure if I could use it.
		 * return Collections.max(this.theGenList);
		 */
	}
	
	/**
	 * Gets the average value of the numbers created
	 * 
	 * @return average of the values in array list
	 */
	public float getAverage() {
		float average = 0;
		float total = 0;
		for (int position = 0; position < this.theGenList.size(); position++) {
			total += this.theGenList.get(position);
			average = total / this.theGenList.size();
		}
		return average;
	}
	
	/**
	 * Sorts the array list of values
	 * 
	 * @return the sorted array list from least to greatest
	 */
	public ArrayList<Integer> getSortedNumbers() {
		this.sort();
		return this.theGenList;
	}
	
	/**
	 * Gets the median value of the numbers created
	 * 
	 * @return median value of the array list
	 */
	public float getMedian() {
		this.sort();
		int size = this.theGenList.size();
		if (size % 2 == 0) {
			int leftOfMid = this.theGenList.get(size / 2 - 1);
			int rightOfMid = this.theGenList.get(size / 2);
			float median = (leftOfMid + rightOfMid) / 2;
			return median;
		} else {
			float median = this.theGenList.get(size / 2);
			return median;
		}	
	}
	
	/**
	 * Takes the array list values and puts them into ascending categories
	 * 
	 * @return theCount: the count of how many values of the array fall into each category  
	 */
	public int [] getBucketCount() {
		int [] theCount = new int[10];
		
		for (int position = 0; position < this.theGenList.size(); position++) {
			int value = this.theGenList.get(position);
			theCount[(int) Math.floor(value / 10 )]++;
		}
		return theCount;
	}
	
	private void sort() {
		Collections.sort(this.theGenList);
	}
}
