package edu.westga.cs6311.drinks;

/**
 * A Soda Machine code.
 * 
 * @author William Pevytoe
 * 
 * @version 9/05/23
 */

public class SodaMachineTester {
	/**
	 * entery point into app
	 * 
	 * @param args not used in the app
	 */
	public static void main(String[] args) {
		SodaMachine customer1 = new SodaMachine();
		System.out.println("Transaction one");
		customer1.chooseCoke();
		System.out.println("Amount Due: " + customer1.getTotalDue());
		customer1.insertQuarter(1.00);
		customer1.insertDollar(1.00);
		System.out.println("Change " + customer1.completePurchase());

		System.out.println("");
		System.out.println("Transaction two");
		SodaMachine customer2 = new SodaMachine();
		customer2.chooseCoke();
		System.out.println("Amount Due: " + customer2.getTotalDue());
		customer2.insertDime(2.00);
		customer2.insertPenny(50.00);
		System.out.println("Change " + customer2.completePurchase());

		System.out.println("");
		System.out.println("Transaction three");
		SodaMachine customer3 = new SodaMachine();
		customer3.choosePepsi();
		System.out.println("Amount Due: " + customer3.getTotalDue());
		customer3.insertDollar(4.00);
		System.out.println("Change " + customer3.completePurchase());

		System.out.println("");
		System.out.println("Transaction Four");
		SodaMachine customer4 = new SodaMachine();
		customer4.choosePepsi();
		customer4.chooseCoke();
		System.out.println("Amount Due: " + customer4.getTotalDue());
		customer4.insertDollar(1.00);
		customer4.insertQuarter(1.00);
		System.out.println("Change " + customer4.completePurchase());

	}

}
