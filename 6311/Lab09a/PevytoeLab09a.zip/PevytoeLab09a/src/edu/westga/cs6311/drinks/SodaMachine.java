/**
 * 
 */

package edu.westga.cs6311.drinks;

/**
 * A Soda Machine code.
 * 
 * @author William Pevytoe
 * 
 * @version 9/05/23
 */
public class SodaMachine {
	/**
	 * Private Values.
	 */
	private double totalCost;
	private double totalInserted;

	/**
	 * The Current Value.
	 * 
	 */
	public SodaMachine() {
		this.totalCost = 0.0;
		this.totalInserted = 0.0;
	}

	/**
	 * Customer Selects a soda
	 */
	public void chooseCoke() {
		this.totalCost = this.totalCost + 1.25;
	}

	/**
	 * Cost of a Pepsi added to @totalCost
	 */
	public void choosePepsi() {
		this.totalCost = this.totalCost + 1.10;
	}

	/**
	 * Total amount of the soda to be purchased
	 * 
	 * @return the @totalCost
	 *
	 */
	public double getTotalDue() {
		return this.totalCost;
	}

	/**
	 * Total amount of money inserted by customer The @amount is the money inserted
	 * by customer
	 * 
	 * @param amount is the coins provided by customer
	 */
	public void insertCoin(double amount) {
		this.totalInserted = this.totalInserted + amount;
	}

	/**
	 * Total Dollar bills inserted by customer
	 * 
	 * @param amount adding Dollars
	 */
	public void insertDollar(double amount) {
		final double subTotal;
		subTotal = amount * 1;
		this.insertCoin(subTotal);
	}

	/**
	 * Total Quarter inserted by customer
	 * 
	 * 
	 * @param amount adding quarters
	 */
	public void insertQuarter(double amount) {
		final double subTotal;
		subTotal = amount * .25;
		this.insertCoin(subTotal);
	}

	/**
	 * Total Dime inserted by customer
	 * 
	 * @param amount adding dimes
	 */
	public void insertDime(double amount) {
		final double subTotal;
		subTotal = amount * .10;
		this.insertCoin(subTotal);
	}

	/**
	 * Total Nickel bills inserted by customer
	 * 
	 * @param amount adding Nickel
	 */
	public void insertNickel(double amount) {
		final double subTotal;
		subTotal = amount * .05;
		this.insertCoin(subTotal);
	}

	/**
	 * Total Dollar bills inserted by customer
	 * 
	 * @param amount adding Dollars
	 */
	public void insertPenny(double amount) {
		final double subTotal;
		subTotal = amount * .01;
		this.insertCoin(subTotal);
	}

	/**
	 * The total change due to customer reseting the @totalCost and @totalInserted
	 * 
	 * @return the change to customer
	 */
	public double completePurchase() {
		double change = this.totalInserted - this.totalCost;
		this.totalCost = 0.0;
		this.totalInserted = 0.0;
		return change;
	}
}
