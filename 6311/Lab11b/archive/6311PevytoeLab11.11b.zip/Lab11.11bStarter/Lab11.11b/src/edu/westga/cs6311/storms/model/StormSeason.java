package edu.westga.cs6311.storms.model;

import java.util.ArrayList;

/**
 * The StormSeason class will keep track of a collection of Hurricane objects. It will provide the 
 * ability to get some summary statistics on its storms by providing the minimum, maximum, and average 
 * wind speeds, as well as providing the number of Category 1, 2, etc both numerically and graphically
 * 
 * @author William Pevytoe
 * 
 * @version 11/1/2023
 */

public class StormSeason {
	private ArrayList<Hurricane> theStorm;
	
	/**
	 * Create a new instances of the StormSeason with 
	 * an empty collection of Hurricane objects 
	 */
	public StormSeason() {
		this.theStorm = new ArrayList<Hurricane>();
	}
	
	/**
	 * Adds the new Hurricane object to the array
	 * 
	 * @param newHurricane the new object to be added to the array
	 */
	public void addHurricane(Hurricane newHurricane) {
		if (newHurricane != null) {
			this.theStorm.add(newHurricane);
		}	
	}
	
	/**
	 * Converts each object in the array to a string listed on a new line each
	 * 
	 * @return the array objects in a string form
	 */
	public String toString() {
		String theResult = "";
		for (Hurricane storm : this.theStorm) {
			theResult += storm.toString() + System.lineSeparator();
		}
		return theResult;
	}
	
	/**
	 * Gets the max wind speed of the storm
	 * 
	 * @return the max wind speed
	 */
	public int getMaximumSpeed() {
		int maxValue = 0;
		int currentValue = 0;
		for (Hurricane storm : this.theStorm) {
			currentValue = storm.getWindSpeed();
			if (currentValue > maxValue) {
				maxValue = currentValue;
			}
		}
		return maxValue;
	}
	
	/**
	 * Gets the max wind speed of the storm
	 * 
	 * @return the max wind speed
	 */
	public int getMinimumSpeed() {
		int currentValue = 0;
		int minValue = Integer.MAX_VALUE;
		for (Hurricane storm : this.theStorm) {
			currentValue = storm.getWindSpeed();
			if (currentValue < minValue) {
				minValue = currentValue;
			}
		}
		return minValue;
	}
	
	/**
	 * Calculate and return the average wind speed 
	 * for all Hurricanes in the collection
	 * 
	 * @return the average wind speed
	 */
	public double getAverageSpeed() {
		double currentValue = 0;
		double averageValue = 0;
		double totalValue = 0;
		int numStorms = this.theStorm.size();
		for (Hurricane storm : this.theStorm) {
			currentValue = storm.getWindSpeed();
			totalValue += currentValue;
			averageValue = totalValue / numStorms;
		}
		return averageValue;
	}
	
	private int[] calculateCategoryBreakdown() {
		int[] categoryCount = new int[5];
		for (Hurricane storm : this.theStorm) {
			int windSpeed = storm.getWindSpeed();
			if (windSpeed >= 74 && windSpeed <= 95) {
				categoryCount[0]++;
			} else if (windSpeed >= 96 && windSpeed <= 110) {
				categoryCount[1]++;
			} else if (windSpeed >= 111 && windSpeed <= 129) {
				categoryCount[2]++;
			} else if (windSpeed >= 130 && windSpeed <= 156) {
				categoryCount[3]++;
			} else if (windSpeed >= 157) {
				categoryCount[4]++;
			}
		}
		return categoryCount;
	}
	
	/**
	 * Creates a Category list
	 * 
	 * @return the histogram
	 */
	public String getCategoryBreakdown() {
		int[] categoryCount = this.calculateCategoryBreakdown();
		String breakdown = "";
		for (int position = 0; position < this.theStorm.size(); position++) {
			breakdown += "Category " + position + ": " + categoryCount[position] + "\n";
		}
		return breakdown;
	}

	private String makeStarRow(int number) {
		String stars = "";
        for (int position = 0; position < number; position++) {
            stars += "*";
        }
        return stars;
    }
	
	/**
	 * Creates a Histogram
	 * 
	 * @return the histogram
	 */
	public String getCategoryHistogram() {
		String histogram = "";
		for (int count : this.calculateCategoryBreakdown()) {
			histogram += this.makeStarRow(count) + "\n";
			}
    return histogram;
	}
}

