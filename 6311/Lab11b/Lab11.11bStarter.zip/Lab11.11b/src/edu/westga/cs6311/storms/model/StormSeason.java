package edu.westga.cs6311.storms.model;

public class StormSeason {

}
