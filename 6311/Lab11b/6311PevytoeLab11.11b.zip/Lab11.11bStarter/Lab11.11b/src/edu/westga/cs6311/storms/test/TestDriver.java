package edu.westga.cs6311.storms.test;

/**
 * Program starter
 * 
 * @author William Pevytoe
 * 
 * @version 11/1/2023
 * 
 */
public class TestDriver {

	/**
	 * running the SeasonTester
	 * 
	 * @param args not used
	 */
	public static void main(String[] args) {
		SeasonTester demo1 = new SeasonTester();
		demo1.runTests();

	}

}
