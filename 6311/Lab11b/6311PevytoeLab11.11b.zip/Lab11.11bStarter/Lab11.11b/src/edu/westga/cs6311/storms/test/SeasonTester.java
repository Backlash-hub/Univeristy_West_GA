package edu.westga.cs6311.storms.test;

import edu.westga.cs6311.storms.model.StormSeason;
import edu.westga.cs6311.storms.model.Hurricane;

/**
 * 
 * Testing the StormSeason
 * 
 * @author William Pevytoe
 * 
 * @version 11/1/2023
 * 
 */
public class SeasonTester {
	private StormSeason theSeason;
	private String[] names;
	private int[] speed;
	
	/**
	 * Construct the hurricane 
	 */
	public SeasonTester() {
		this.theSeason = new StormSeason();
		this.names = new String[] {"Sally", "Will", "Tommy", "John", "Oscar"};
		this.speed = new int[] {76, 80, 120, 145, 160};
		
	}
	
	/**
	 * Call the methods that are to be tested
	 */
	public void runTests() {
		System.out.println("Testing the Hurricane");
		this.createHurricanes();
		System.out.println("");
		this.minSpeed();
		System.out.println("");
		this.maxSpeed();
		System.out.println("");
		this.aveSpeed();
		System.out.println("");
		this.category();
		System.out.println("");
		this.histagram();
	}
	
	/**
	 * Creates the Hurricanes
	 */	
	public void createHurricanes() {
		for (int position = 0; position < this.names.length; position++) {
			Hurricane storm = new Hurricane(this.names[position], this.speed[position]);
			this.theSeason.addHurricane(storm);
		}
		System.out.print(this.theSeason);
	}
	
	/**
	 * Gets the minimum wind speed
	 */
	public void minSpeed() {
		System.out.println("Getting MIN wind speed");
		System.out.println("Expected:\t" + 76);
		System.out.println("Actual:\t\t" + this.theSeason.getMinimumSpeed());
	}
	
	/**
	 * Gets the max wind speed
	 */
	public void maxSpeed() {
		System.out.println("Getting MAX wind speed");
		System.out.println("Expected:\t" + 160);
		System.out.println("Actual:\t\t" + this.theSeason.getMaximumSpeed());
	}
	
	/**
	 * Gets the average wind speed
	 */
	public void aveSpeed() {
		System.out.println("Getting AVERAGE wind speed");
		System.out.println("Expected:\t" + 116.2);
		System.out.println("Actual:\t\t" + this.theSeason.getAverageSpeed());
	}
	
	/**
	 * Gets the category breakdown
	 */
	public void category() {
		System.out.println(this.theSeason.getCategoryBreakdown());
	}
	
	/**
	 * Gets the histogram
	 */
	public void histagram() {
		System.out.println(this.theSeason.getCategoryHistogram());
	}
}
