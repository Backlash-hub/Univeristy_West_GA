/**
 * 
 */

package edu.westga.cs6311.humans.controller;

import java.util.Scanner;

import edu.westga.cs6311.humans.model.Human;

/**
 * User Input to Create Humans
 * 
 * @author William Pevytoe
 * 
 * @version 9/22/23
 */
public class InteractiveHumanDemo {
	private Scanner humanValues;
	private Human person;
	
	
	public InteractiveHumanDemo() {
		this.humanValues = new Scanner(System.in);
		
	}
	
	public void runHuman() {
		System.out.println("");
		System.out.println("----Interactive Mode----");
		System.out.println("Enter the human's name: ");
		String huamnOneName = humanValues.nextLine();
		System.out.println("Enter the human's year of birth: ");
		String humanOneYear = humanValues.nextLine();
		int humanOneNumber = Integer.parseInt(humanOneYear);
		this.person = new Human(huamnOneName, humanOneNumber);
		System.out.println(this.person.toString());
		System.out.println("The human's age: " + this.person.getAge());
		System.out.println("");
		
		System.out.println("Enter the second human's name: ");
		String huamnTwoName = humanValues.nextLine();
		System.out.println("Enter the second human's year of birth: ");
		String humanTwoYear = humanValues.nextLine();
		int humanTwoNumber = Integer.parseInt(humanTwoYear);
		Human humanNumberTwo = new Human(huamnTwoName, humanTwoNumber);
		System.out.println(humanNumberTwo.toString());
		System.out.println("The human's age: " + humanNumberTwo.getAge());
		System.out.println("");
		
		System.out.println("The age difference here is:\t" + this.person.getAgeDifferenceBetween(humanNumberTwo));
		System.out.println("The age difference here is (2):\t" + humanNumberTwo.getAgeDifferenceBetween(this.person));
		System.out.println("");
		System.out.println("The average age here is:\t" + this.person.getAverageAgeOf(humanNumberTwo));
		System.out.println("");
		System.out.println("The youngest age here is:\t" + this.person.getAgeOfYounger(humanNumberTwo));
		System.out.println("The youngest age here is (2):\t" + humanNumberTwo.getAgeOfYounger(this.person));
		System.out.println("");
		System.out.println("The oldgest age here is:\t" + this.person.getAgeOfOlder(humanNumberTwo));
		System.out.println("The oldgest age here is (2):\t" + humanNumberTwo.getAgeOfOlder(this.person));
		humanValues.close();
	}
}
