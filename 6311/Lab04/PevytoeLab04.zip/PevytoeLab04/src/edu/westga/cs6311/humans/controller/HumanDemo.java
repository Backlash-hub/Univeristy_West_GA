/**
 * 
 */

package edu.westga.cs6311.humans.controller;

import edu.westga.cs6311.humans.model.Human;

/**
 * Creating a Human
 * 
 * @author William Pevytoe
 * 
 * @version 9/21/23
 * 
 */
public class HumanDemo {
	private Human person;
	
	/**
	 * Creates HumanDemo object
	 */
	public HumanDemo() {
		String name = "William";
		int year = 1990;
		this.person = new Human(name, year);
	}

	/**
	 * Displays the message string from the human class
	 */
	public void testSingleHuman() {
		System.out.println(this.person.toString());
		System.out.println("");
		System.out.println("The expected age:\t 33");
		System.out.println("The actual age:\t\t " + this.person.getAge());
		System.out.println("");
	}
	
	/**
	 * Test the age difference in the two humans
	 */
	public void testTwoHumans() {
		Human person2 = new Human("Greg", 1995);
		System.out.println(person2.toString());
		System.out.println("");
		System.out.println("Expected difference in age is:\t 5");
		System.out.println("Actual age difference is:\t " + this.person.getAgeDifferenceBetween(person2));
		System.out.println("Actual age difference is:\t " + person2.getAgeDifferenceBetween(this.person));
	}
}
