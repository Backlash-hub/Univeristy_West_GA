/**
 * 
 */

package edu.westga.cs6311.humans.model;

/**
 * Creating a human
 * 
 * @author William Pevytoe
 * 
 * @version 9/21/23
 * 
 */
public class Human {
	private String name;
	private int birthYear;

	/**
	 * Creates the Human utilizing the name and birth year
	 * 
	 * @param humanName is the name of the individual
	 * @param year      is the 4 integer birth year of the human
	 */
	public Human(String humanName, int year) {
		this.name = humanName;
		this.birthYear = year;
	}

	/**
	 * Creates a string that will print the name and year of birth of the human
	 * 
	 * @return the message string
	 */
	public String toString() {
		String message = new String(this.name + " was born in the year " + this.birthYear + ".");
		return message;
	}
	
	public int getAge() {
		int age = 2023 - this.birthYear;
		return age;
	}
	
	public int getAgeDifferenceBetween(Human anotherHuman) {
		return Math.abs(getAge() - anotherHuman.getAge());
	}
	
	public double getAverageAgeOf(Human anotherHuman) {
		return (getAge() + anotherHuman.getAge()) / 2;
	}
	
	public int getAgeOfYounger(Human anotherHuman) {
		return Math.min(getAge(), anotherHuman.getAge());
	}
	
	public int getAgeOfOlder(Human anotherHuman) {
		return Math.max(getAge(), anotherHuman.getAge());
	}
}

