package edu.westga.cs6311.humans.controller;

/**
 * Testing the HumanDemo Class
 * 
 * @author William Pevytoe
 * 
 * @version 9/21/23
 */
public class HumanDriver {

	/**
	 * Entry point for the program.
	 * 
	 * @param args not used
	 */
	public static void main(String[] args) {
		HumanDemo demo1 = new HumanDemo();
		demo1.testSingleHuman();
		demo1.testTwoHumans();
		InteractiveHumanDemo demo2 = new InteractiveHumanDemo();
		demo2.runHuman();
	}

}
