package edu.westga.cs6311.lab02b;

/**
 *  @author William Pevytoe
 *  @version 8/23/2023
 **/

import java.util.Scanner;

public class StringDriver {
  public static void main(final String[] args) {
    Scanner input = new Scanner(System.in);

    //Enter first name
    System.out.println("Enter your first name: ");
    final String firstname = input.nextLine();

    //Enter last name
    System.out.println("Enter your last name: ");
    final String lastname = input.nextLine();

    //Print total name
    System.out.println(lastname + ", " + firstname);

    //Generate a standard Username
    final String Fname = firstname.substring(0, 1);
    final String Lname = lastname.substring(0, 3);

    //Print Username
    System.out.println(Fname + "." + Lname);

    //Phrase
    System.out.println("Enter a phrase: ");
    final String phrase = input.nextLine();

    //Letter to be replaced
    System.out.println("Enter a letter to be replaced: ");
    final String repOld = input.nextLine();

    //Letter that will be replacing repL
    System.out.println("Enter the letter you want the " + repOld + " to be replced by: ");
    final String repNew = input.nextLine();

    //Replacing repOld with repNew
    final String newPhrase = phrase.replace(repOld, repNew);

    //New phrase
    System.out.println(newPhrase);

    //Generate random Phone number
    final int sec1 = (int) (Math.random() * (899 - 201 + 1) + 201);
    final int sec21 = (int) (Math.random() * (7 - 2) + 1) + 2;
    final int sec22 = (int) (Math.random() * (7 - 2) + 1) + 2;
    final int sec23 = (int) (Math.random() * (7 - 2) + 1) + 2;
    final int sec3 = (int) (Math.random() * (9999 - 1000 + 1) + 1000);
    System.out.println("The random phone number is:"
        + " " + "(" + sec1 + ") " + sec21 + sec22 + sec23 + " - " + sec3);
    input.close();
  }
}
