/**
 * 
 */

package edu.westga.cs6311.storms.controller;

import java.util.Scanner;

import edu.westga.cs6311.storms.model.Hurricane;

/**
* User input for Hurricanes
* 
*@author William Pevytoe
*
*@version 10/2/23
*/
public class InteractiveHurricane {
	private Scanner input;
	private Hurricane storm;
	private String message;
	private int number;
	
	/**
	 * Creating Scanner and setting variables
	 */
	public InteractiveHurricane() {
		this.input = new Scanner(System.in);
		this.storm = null;
		this.message = null;
		this.number = 0;
	}
	
	/**
	 * Create User inputs
	 */
	public void inputHurricaneValues() {
		System.out.println("Enter the hurricane's name: ");
		this.message = this.input.nextLine();
		
		System.out.println("Enter the hurricane's max wind speed: ");
		this.number = Integer.parseInt(this.input.nextLine());
	}
	
	/**
	 * Initializes the new hurricane with the users input
	 */
	public void initializeHurricane() {
		this.storm = new Hurricane(this.message, this.number);
	}
	
	/**
	 * Runs the methods from Hurricane
	 */
	public void demonstrateHurricane() {
		System.out.println("The hurriane name is:\t\t" + this.storm.getName());
		System.out.println("The hurricane wind speed is:\t" + this.storm.getWindSpeed());
		System.out.println("Is the hurricane a major storm?\t" + this.storm.isMajorStorm());
		System.out.println("The hurricane catagory:\t\t" + this.storm.getCategory());
	}

}
