package edu.westga.cs6311.storms.model;

/**
 * The Hurricane class represents a snapshot of a storm.  This class
 * 	can calculate the storm's category based on the wind speed
 * 	according to the Saffir-Simpson scale:
 * 		74 - 95		Category 1
 * 		96 - 110	Category 2
 * 		111 - 129	Category 3
 * 		130 - 156	Category 4
 * 		otherwise	Category 5
 * 
 * NOTE: The Category 5 can only be defined this way because of our 
 * 	defensive programming requirement that every Hurricane object will 
 * 	have a wind speed of at least 74 miles an hour (otherwise, it wouldn't
 * 	be a hurricane)
 * 
 * It can also determine if a Hurricane is major storm
 * 	(must be Category 3 or stronger) and whether this storm is
 * 	stronger than another Hurricane
 * 
 * Starter file created by CS6311
 * 
 * @author William Pevytoe
 * 
 * @version 10/02/23
 *
 */
public class Hurricane {
	private static final int CATEGORY1_MINIMUM = 74;
	private static final int CATEGORY2_MINIMUM = 96;
	private static final int CATEGORY3_MINIMUM = 111;
	private static final int CATEGORY4_MINIMUM = 130;
	private static final int CATEGORY5_MINIMUM = 157;
	
	private String name;
	private int maximumWindSpeed;
	
	/**
	 * Creates a new Hurricane object with the given name and
	 * 	maximum wind speed
	 * 
	 * @param	name		The Hurricane's name
	 * @param	windSpeed	The Hurricane's maximum wind speed
	 * 
	 * @precondition	windSpeed >= 74 (CATEGORY1_MINIMUM)
	 */
	public Hurricane(String name, int windSpeed) {
		this.name = name;
		this.maximumWindSpeed = windSpeed;
		if (windSpeed < CATEGORY1_MINIMUM) {
			windSpeed = CATEGORY1_MINIMUM;			
		}
	}
	
	/**
	 * Returns the name of this Hurricane
	 * 
	 * @precondition	None
	 * @return			The name of this Hurricane
	 */
	public String getName() {
		String name = new String(this.name);
		return name;
	}
	
	/**
	 * Returns the maximum wind speed of this Hurricane
	 * 
	 * @precondition	None
	 * @return			The maximum wind speed of this Hurricane
	 */
	public int getWindSpeed() {
		return this.maximumWindSpeed;
	}
	
	/**
	 * Returns true if the wind speed is greater than or equal to 
	 * 	the speed necessary for it to be considered a Category 3
	 * 	storm, and false otherwise
	 * 
	 * @precondition	None
	 * @return			true if and only if getWindSpeed() >= the 
	 * 						minimum wind speed for a Category 3 storm
	 */
	public boolean isMajorStorm() {
		boolean majorStorm = false;
		if (this.getWindSpeed() >= CATEGORY3_MINIMUM) {
			majorStorm = true;
		} 
		return majorStorm;
	}

	/**
	 * Returns the storm's category corresponding to the maximum wind speed
	 * 	as determined by the Saffir-Simpson scale
	 * 
	 * @precondition	None
	 * @return			1, if windSpeed < 96 (CATEGORY2_MINIMUM)
	 * 					2, if windSpeed < 111 (CATEGORY3_MINIMUM)
	 * 					3, if windSpeed < 130 (CATEGORY4_MINIMUM)
	 * 					4, if windSpeed < 157 ((CATEGORY5_MINIMUM)
	 * 					5, otherwise
	 */
	public int getCategory() {
		int category = 0;
		if (this.getWindSpeed() < CATEGORY2_MINIMUM) {
			category = 1;
		} else if (this.getWindSpeed() < CATEGORY3_MINIMUM) {
			category = 2; 
		} else if (this.getWindSpeed() < CATEGORY4_MINIMUM) {
			category = 3; 
		} else if (this.getWindSpeed() < CATEGORY5_MINIMUM) {
			category = 4; 
		} else {
			category = 5;
		} 
		return category;
	}
	
	/**
	 * Returns true if this Hurricane's wind speed is greater than the 
	 * 	wind speed of the Hurricane that is passed in, and false otherwise
	 * 
	 * @precondition	None
	 * 
	 * @param	anotherHurricane	The other Hurricane object to be compared
	 * 
	 * @return	true if and only if getWindSpeed() > anotherHurricane.getWindSpeed()
	 */
	public boolean isStrongerThan(Hurricane anotherHurricane) {
		boolean stronger = false;
		if (this.getWindSpeed() > anotherHurricane.getWindSpeed()) {
			stronger = true; 
		}
		return stronger;
		
	}
}

