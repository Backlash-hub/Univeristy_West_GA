/**
 * 
 */

package edu.westga.cs6311.storms.controller;

/**
 * Testing the InteractiveHurricane Class
 * 
 * @author William Pevytoe
 * 
 * @version 10/02/23
 */
public class HurricaneDemonstrationDriver {

	/**
	 * Entry point for Interactive program
	 * 
	 * @param args not used
	 */
	public static void main(String[] args) {
		InteractiveHurricane demo1 = new InteractiveHurricane();
		demo1.inputHurricaneValues();
		demo1.initializeHurricane();
		demo1.demonstrateHurricane();		
	}
}
