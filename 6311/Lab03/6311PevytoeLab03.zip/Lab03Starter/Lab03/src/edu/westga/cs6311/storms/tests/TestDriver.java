package edu.westga.cs6311.storms.tests;

/**
 * This class creates a HurricaneTester object and calls its runTests method
 * 
 * Starter file created by CS6311
 *
 * @author William Pevytoe
 * 
 * @version 10/02/23
 *
 */
public class TestDriver {
	/**
	 * Entry point of the application
	 * 
	 * @param args	Not used in this application
	 * 
	 * @precondition	None
	 */
	public static void main(String[] args) {
		HurricaneTester demo1 = new HurricaneTester();
		demo1.runTests();
	}

}