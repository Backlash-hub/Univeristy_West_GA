package edu.westga.cs6311.storms.tests;

import edu.westga.cs6311.storms.model.Hurricane;

/**
 * This class is used to informally test the Hurricane object
 * 
 * Starter file created by CS6311
 * 
 * @author William Pevytoe
 * 
 * @version 10/02/23
 *
 */
public class HurricaneTester {
	private Hurricane barry2019;
	private Hurricane gloria1985;
	private Hurricane andrew1992;
	
	/**
	 * Creates a new HurricaneTester object and creates tester objects
	 * 
	 * @precondition	None
	 */
	public HurricaneTester() {
		this.barry2019 = new Hurricane("Barry", 80);
		this.gloria1985 = new Hurricane("Gloria", 115);
		this.andrew1992 = new Hurricane("Andrew", 165);
	}
	
	/**
	 * This method is used to execute the different sets of test code
	 * 
	 * @precondition	None
	 */
	public void runTests() {
		this.shouldCreateHurricaneWithCorrectWindSpeeds();
		this.categoryShouldBe3ForCategory3();
		this.category3ShouldBeMajor();
		this.category1ShouldNotBeMajor();
		this.strengthOf5ShouldBeGreaterThanStrengthOf1();
	}

	/**
	 * Will check the expected vs actual name and wind speed for the 3 objects
	 */
	private void shouldCreateHurricaneWithCorrectWindSpeeds() {
		System.out.println("Expected name:\t\tBarry");
		System.out.println("Actual name:\t\t" + this.barry2019.getName());
		System.out.println("Expected wind speed:\t80");
		System.out.println("Actual wind speed:\t" + this.barry2019.getWindSpeed());
		System.out.println("");
		
		System.out.println("Expected name:\t\tGloria");
		System.out.println("Actual name:\t\t" + this.gloria1985.getName());
		System.out.println("Expected wind speed:\t115");
		System.out.println("Actual wind speed:\t" + this.gloria1985.getWindSpeed());
		System.out.println("");
		
		System.out.println("Expected name:\t\tAndrew");
		System.out.println("Actual name:\t\t" + this.andrew1992.getName());
		System.out.println("Expected wind speed:\t165");
		System.out.println("Actual wind speed:\t" + this.andrew1992.getWindSpeed());
		System.out.println("");
	}

	/**
	 * Checks if hurricane Gloria is a category 3 hurricane or not 
	 */
	private void categoryShouldBe3ForCategory3() {
		System.out.println("Expected category:\t3");
		System.out.println("Actual category:\t" + this.gloria1985.getCategory());		
	}

	/**
	 * Checks if hurricane Gloria is a major hurricane or not
	 */
	private void category3ShouldBeMajor() {
		System.out.println("Major hurricane:\ttrue");
		System.out.println("Major hurricane:\t" + this.gloria1985.isMajorStorm());
		System.out.println("");		
	}

	/**
	 * Checks if hurricane Barry is a major hurricane or not
	 */
	private void category1ShouldNotBeMajor() {
		System.out.println("Major hurricane:\tfalse");
		System.out.println("Major hurricane:\t" + this.barry2019.isMajorStorm());
		System.out.println("");		
	}

	/**
	 * Checks if hurricane Barry is stronger than Andrew
	 * Checks if hurricane Andrew is stronger than Barry 
	 */
	private void strengthOf5ShouldBeGreaterThanStrengthOf1() {
		System.out.println("Is Hurricane Barry stronger than Hurricane Andrew?");
		System.out.println("Expected comparison :\t false");
		System.out.println("Actual camparison:\t " + this.barry2019.isStrongerThan(this.andrew1992));
		System.out.println("");
		System.out.println("Is Hurricane Andrew stronger than Hurricane Barry?");
		System.out.println("Expected comparison :\t true");
		System.out.println("Actual camparison:\t " + this.andrew1992.isStrongerThan(this.barry2019));		
	}	
}
