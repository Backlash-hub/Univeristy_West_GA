package edu.westga.cs6311.storms2.view;

import edu.westga.cs6311.storms2.model.Hurricane;
import edu.westga.cs6311.storms2.model.StormSeason;
import java.util.Scanner;

/**
 * 
 * User information
 * 
 * @author William Pevytoe
 * 
 * @version 11/8/2023
 * 
 */
public class SeasonView {
	private Scanner userStorm;
	private StormSeason theStorms;
	
	/**
	 * Constructs the User inputs and StormSeason
	 * 
	 * @param aStorm is theStorms objects
	 */
	public SeasonView(StormSeason aStorm) {
		this.userStorm = new Scanner(System.in);
		this.theStorms = aStorm;
	}
	
	/**
	 * Runs the program
	 */
	public void run() {
		System.out.println("-- WELCOME TO THE STORM --");
		System.out.println("");
		this.displayMenu();
		System.out.println("");
		System.out.println("Please make selection: ");
		String userSelection = this.userStorm.nextLine();
		int numSelection = Integer.parseInt(userSelection);
		if (numSelection == 1) {
			this.addHurricane();
			System.out.println("");
			this.run();
		} else if (numSelection == 2) {
			this.removeHurricane();
			System.out.println("");
			this.run();
		} else if (numSelection == 3) {
			this.updateHurricane();
			System.out.println("");
			this.run();
		} else if (numSelection == 4) {
			this.displayStatistics();
			System.out.println("");
			this.run();				
		} else if (numSelection == 5) {
			this.categoryAndHistogram();
			System.out.println("");
			this.run();		
		} else if (numSelection == 6) {
			System.out.println("Goodbye");
		}
		System.out.println("");
		System.out.println("Thank you for using THE STORM");
	}
	
	/**
	 * displays the menu
	 */
	public void displayMenu() {
		System.out.println("1 - Add a hurricane");
		System.out.println("2 - Remove a hurricane");
		System.out.println("3 - Update a hurricane");
		System.out.println("4 - Display season statistics");
		System.out.println("5 - Display category breakdown");
		System.out.println("6 – Quit");	
	}
	
	/**
	 * User adding Hurricane
	 */
	public void addHurricane() {
		System.out.println("Please enter new Hurricane name: ");
		String hurricaneName = this.userStorm.nextLine();
		System.out.println("Please enter Hurricane " +  hurricaneName + "'s " + "wind speed: ");
		String hurricaneSpeed = this.userStorm.nextLine();
		int theSpeed = Integer.parseInt(hurricaneSpeed);
		if (theSpeed < 74) {
			System.out.println("Please enter a whole number greater than 73. Please try again.");
		}
		Hurricane newHurricane = new Hurricane(hurricaneName, theSpeed);
		this.theStorms.addHurricane(newHurricane);	
	}
	
	/**
	 * Displays the hurricanes as a string 
	 */
	public void displayStatistics() {
		System.out.println(this.theStorms.toString());
	}
	
	/**
	 * Displays category breakdown and category histogram
	 */
	public void categoryAndHistogram() {
		System.out.println(this.theStorms.getCategoryBreakdown());
		System.out.println("");
		System.out.println(this.theStorms.getCategoryHistogram());
	}
	
	/**
	 * Removing a hurricane from Array
	 */
	public void removeHurricane() {
		System.out.println("Please enter the Hurricane name: ");
		String hurricaneName = this.userStorm.nextLine();
		if (this.theStorms.findHurricane(hurricaneName) != null) {
			this.theStorms.removeHurricane(this.theStorms.findHurricane(hurricaneName));
			System.out.println("Hurricane " + hurricaneName + " was removed from the list.");
		} else {
			System.out.println("No hurricane with the name " + hurricaneName + " was found.");
		}	
	}
	
	/**
	 * Updating a hurricane wind speed
	 */
	public void updateHurricane() {
		String hurricaneSpeed = null;
		int theSpeed = 0;
		System.out.println("Please enter the Hurricane name: ");
		String hurricaneName = this.userStorm.nextLine();
		if (this.theStorms.findHurricane(hurricaneName) == null) {
			System.out.println("No hurricane with the name " + hurricaneName + " was found.");
			return;
		} else {
			System.out.println("Please enter Hurricane " + hurricaneName + "'s new wind speed: ");
			hurricaneSpeed = this.userStorm.nextLine();
			theSpeed = Integer.parseInt(hurricaneSpeed);
		}
		if (theSpeed > 73) {
			this.theStorms.updateHurricane(this.theStorms.findHurricane(hurricaneName), theSpeed);
		} else {
			System.out.println("Please enter a wind speed greater than 73.");
			return; 
		}
	}
}
