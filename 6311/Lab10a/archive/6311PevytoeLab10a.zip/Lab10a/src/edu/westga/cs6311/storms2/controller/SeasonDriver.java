package edu.westga.cs6311.storms2.controller;

import edu.westga.cs6311.storms2.model.StormSeason;
import edu.westga.cs6311.storms2.view.SeasonView;

/**
 * The Program start
 * 
 * @author William Pevytoe
 * 
 * @version 11/08/2023
 */
public class SeasonDriver {

	/**
	 * Starts the program
	 * 
	 * @param args not used
	 */
	public static void main(String[] args) {
		StormSeason stormSeason = new StormSeason();
		SeasonView seasonView = new SeasonView(stormSeason);
		seasonView.run();
	}

}
