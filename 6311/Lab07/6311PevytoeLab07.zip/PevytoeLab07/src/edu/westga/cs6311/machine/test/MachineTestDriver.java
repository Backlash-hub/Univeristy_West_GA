package edu.westga.cs6311.machine.test;

/**
 * Testing the MachineTest Class
 * 
 * @author William Pevytoe
 *
 * @version 10/11/23
 */

public class MachineTestDriver {
	
	/**
	 * Running the MachineTest
	 * 
	 * @param args not used
	 */
	public static void main(String[] args) {
		MachineTest demo1 = new MachineTest();
		demo1.runTests();
	}
}
