package edu.westga.cs6311.machine.controller;

import edu.westga.cs6311.machine.test.MachineTestDriver;
import edu.westga.cs6311.machine.view.InteractiveMachineView;

/**
 * Runs the test and the Interactive Machine 
 * 
 * @author William Pevytoe
 *
 * @version 10/16/23
 */
public class MachineDriver {

	/**
	 * Entry point for the program
	 * 
	 * @param args not used
	 */
	public static void main(String[] args) {
		MachineTestDriver.main(args);
		System.out.println("");
		InteractiveMachineView interactive = new InteractiveMachineView();
		interactive.runMachine();
	}
}

