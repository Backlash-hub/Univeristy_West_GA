package edu.westga.cs6311.machine.model;

/**
 * Defines the possible path vales for the ball to fall
 * 
 * @author William Pevytoe
 *
 * @version 10/16/23
 */

public class Path {
	private String directionPath;

	/**
	 * Constructor used to initialize the Path object
	 */
	public Path() {
		this.directionPath = "";
		
	}

	/**
	 * Adds "R" to the path
	 */
	public void moveRight() {
		this.directionPath += "R";
	}

	/**
	 * Adds "L" to the path
	 */
	public void moveLeft() {
		this.directionPath += "L";
	}

	/**
	 * For the number of levels the on the Plinko board, either have the ball fall
	 * right or left
	 * 
	 * @param number the levels of the Plinko board
	 */
	public void fallLevels(int number) {
		for (int poll = 0; poll < number; poll++) {
			int probability = (int) (Math.random() * 2 + 1);
			if (probability == 1) {
				this.moveLeft();
			} else {
				this.moveRight();
			}
		}
	}

	/**
	 * Gets the total path the ball fell
	 * 
	 * @return the direction the ball fell from each peg
	 */
	public String getPath() {
		return this.directionPath;
	}

}
