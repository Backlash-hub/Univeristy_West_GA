package edu.westga.cs6311.machine.test;

import edu.westga.cs6311.machine.model.Path;
import edu.westga.cs6311.machine.model.BeanMachine;

/**
 * Testing the Path and BeanMachine outputs
 * 
 * @author William Pevytoe
 *
 * @version 10/11/23
 */

public class MachineTest {
		private Path directions;
		private int levels;
		private BeanMachine theMachine;
		private int totalBeansDropped;
		
		/**
		 * Constructs the Path, the BeanMachine, and sets variables 
		 */
		public MachineTest() {
			this.directions = new Path();
			this.levels = 7;
			this.totalBeansDropped = 100;
			this.theMachine = new BeanMachine(this.levels);
			
		}
		
		/**
		 * Call the methods that are to be tested
		 */
		public void runTests() {
			this.directions.fallLevels(this.levels);
			String testOutput = this.directions.getPath();
			this.testPathNotEmpty(testOutput);
			this.testPathLevelsVsDescription(testOutput);
			this.testBeanMachineBeansVsDropped();
		}
		
		/**
		 * Verify that the Path is not an empty string
		 * 
		 * @param testOutput is the new Path object
		 */
		public void testPathNotEmpty(String testOutput) {
			System.out.println("Verify path not empty:\nPath=\t'" + testOutput + "'"); 
			System.out.println("");
		}
		
		/**
		 * Tests the number of levels is equal to the number of directions (L or R) in the path.
		 * 
		 * @param testOutput is the new Path object
		 */
		public void testPathLevelsVsDescription(String testOutput) {
			System.out.println("Verify the number of levels is equal to the number of path directions:\n"
					+ "Levels=\t\t" + this.levels + "\nDirections=\t" + testOutput.length());
			System.out.println("");
		}
		
		/**
		 * Tests to see if the total number of beans dropped equals the number in the buckets
		 */
		public void testBeanMachineBeansVsDropped() {
			System.out.println("Testing the Bean Machine");
			System.out.println("The expected number of beans dropped in buckets:\t" + this.totalBeansDropped);
			
			this.theMachine.simulateGame(this.totalBeansDropped);
			String[] theDescription = this.theMachine.getBinDescription().split("\n");
			
			int total = 0;
			for (int position = 0; position <  theDescription.length; position++) {
				total += Integer.parseInt(theDescription[position].split(" ")[1]);
			}
						
			System.out.println("The actual number of beans dropped in buckets:\t\t" + total);
		}
}

