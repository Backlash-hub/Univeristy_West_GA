package edu.westga.cs6311.machine.model;

/**
 * This is the BeanMachine
 * 
 * @author William Pevytoe
 *
 * @version 10/16/23 
 */
public class BeanMachine {
	private int levelsOfPegs;
	private int[] beanBuckets;
	
	/**
	 * Constructs the BeanMachine
	 * 
	 * @param totalLevelsOfPegs the number of levels for the machine 
	 */
	public BeanMachine(int totalLevelsOfPegs) {
		this.levelsOfPegs = totalLevelsOfPegs;
		this.beanBuckets = new int[totalLevelsOfPegs + 1];
	}
	
	/**
	 * Simulate dropping the bean at the top of the board a specific number of times
	 * 
	 * @param numberOfBeans how time times a bean is dropped
	 */
	public void simulateGame(int numberOfBeans) {
		for (int bean = 0; bean < numberOfBeans; bean++) {
			Path beanPath = new Path();
			beanPath.fallLevels(this.levelsOfPegs);
			int finalPosition = this.getBinResult(beanPath.getPath());
			this.beanBuckets[finalPosition]++;			
		}
		
	}
	
	/**
	 * The bin the ball lands in
	 * 
	 * @param thePath is the string from the Path Class
	 * @return the bin number
	 */
	public int getBinResult(String thePath) {
		int position = 0;
		for (int location = 0; location < thePath.length(); location++) {
			Character fallDirection = thePath.charAt(location);
			if (fallDirection == 'R') {
				position++;		
			}
		}
		return position;
	}
	
	/**
	 * Describes the bins and the number of balls in each
	 * 
	 * @return the number of balls in each bin
	 */
	public String getBinDescription() {
		String description = "";
		for (int position = 0; position < this.beanBuckets.length; position++) {
			description = description + "[" + position + "]: " + this.beanBuckets[position] + "\n";
		}
		return description;
	}
}
