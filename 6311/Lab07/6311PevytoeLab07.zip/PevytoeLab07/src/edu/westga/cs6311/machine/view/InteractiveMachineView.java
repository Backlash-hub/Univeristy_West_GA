package edu.westga.cs6311.machine.view;

import java.util.Scanner;

import edu.westga.cs6311.machine.model.BeanMachine;

/**
 * Takes User input to create the Bean Machine and generate the Path
 * 
 * @author William Pevytoe
 *
 * @version 10/16/23
 */

public class InteractiveMachineView {
	private Scanner input;
	private BeanMachine theMachine;

	/**
	 * Initialize the Scanner
	 */
	public InteractiveMachineView() {
		this.input = new Scanner(System.in);
	}

	/**
	 * Takes the users input and calls the corresponding methods to create the Bean
	 * Machine and Path
	 */
	public void runMachine() {
		System.out.println("Enter the number of levels for the machine: ");
		String levels = this.input.nextLine();
		int totalLevels = Integer.parseInt(levels);
		System.out.println("Enter the number of beans you want to drop: ");
		String beans = this.input.nextLine();
		int totalBeans = Integer.parseInt(beans);
		this.theMachine = new BeanMachine(totalLevels);
		this.theMachine.simulateGame(totalBeans);
		System.out.println(this.theMachine.getBinDescription());
		System.out.println("");
		System.out.println("Would you like to play again (y/n): ");
		String playAgain = this.input.nextLine();
		if (playAgain.equalsIgnoreCase("y")) {
			this.runMachine();
		} else {
			System.out.println("Goodbye");
			System.exit(0);
		}
	}
}
