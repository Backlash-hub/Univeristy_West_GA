/**
 * 
 */
package edu.westga.cs6311.firstprogram;

/**
 @author William Pevytoe
 @version 8/9/2023
 */
public class WilliamPevytoe {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Name: William Pevytoe");
		System.out.println("Undergraduate Major: Bs in Criminal Justice and BS in Cybersecurity");
		System.out.println("Favorite Movie: Den of Theives");
		System.out.println("Dream Vacation: Hunting in New Foundland");
		System.out.println("");
		System.out.println("");
		System.out.println("*          *           *  *      *  *******");
		System.out.println(" *        * *        *    *      *  *      *");
		System.out.println("  *      *   *      *     ********  *      *");
		System.out.println("   *    *     *    *      *      *  *******");
		System.out.println("    *  *       *  *       *      *  *");
		System.out.println("     **         **        *      *  *");
	}

}
