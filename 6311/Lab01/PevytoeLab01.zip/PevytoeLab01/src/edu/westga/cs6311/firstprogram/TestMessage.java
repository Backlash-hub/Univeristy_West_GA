package edu.westga.cs6311.firstprogram;

public class TestMessage {
	public static void main(String [] args) {
		System.out.println("An Important Message");
	}
}
