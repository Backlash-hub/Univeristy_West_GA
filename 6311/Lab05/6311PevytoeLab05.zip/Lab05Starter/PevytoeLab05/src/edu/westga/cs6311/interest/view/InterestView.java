package edu.westga.cs6311.interest.view;

import java.util.Scanner;

import edu.westga.cs6311.interest.model.Account;
import edu.westga.cs6311.interest.model.BalanceBuilder;

/**
 * User input to create the data table
 * 
 * @author William Pevytoe
 *
 * @version 10/04/23
 * 
 */
public class InterestView {
	private BalanceBuilder theBalance;
	private Scanner input;
	
	/**
	 * Initiates the balance and the scanner 
	 */
	public InterestView() {
		this.theBalance = new BalanceBuilder();
		this.input = new Scanner(System.in);
	}
	
	/**
	 * The direct flow for the application 
	 * Calls the helper methods to create the table with the appropriate user data 
	 */
	public void run() {
		double balance = this.inputInitialBalance();
		double rate = this.inputRate();
		int years = this.inputNumberOfYears();
		Account theNewAccount = new Account(balance, rate);
		this.theBalance.setAccount(theNewAccount);
		this.theBalance.setYears(years);
		this.theBalance.buildTable();
		System.out.println(this.theBalance.getResults());
	}
	
	/**
	 * Creates the starting balance
	 * @return the starting balance
	 */
	public double inputInitialBalance() {
		System.out.println("Enter the initial balance (Must be more than 0): ");
		double balance = Double.parseDouble(this.input.nextLine());
		while (balance == 0) {
			System.out.println("Enter appropriate initial balance (other than 0): ");
			balance = Double.parseDouble(this.input.nextLine());
		}
		return balance;		
	}
	
	/**
	 * Creates the initial rate
	 * @return the initial rate
	 */
	public double inputRate() {
		System.out.println("Enter the initial rate (between 0 and 1): ");
		double rate = Double.parseDouble(this.input.nextLine());
		while (rate <= 0.0 || rate > 1.0) {
			System.out.println("Enter appropriate initial rate (between 0 and 1): ");
			rate = Double.parseDouble(this.input.nextLine());
		}
		return rate;
	}
	
	/**
	 * Creates the number of years 
	 * @return the number of years
	 */
	public int inputNumberOfYears() {
		System.out.println("Enter the initial number of years (between 1 and 10): ");
		int years = Integer.parseInt(this.input.nextLine());
		while (years < 1) {
			System.out.println("Enter appropriate the initial number of years (between 1 and 10): ");
			years = Integer.parseInt(this.input.nextLine());
		}
		return years;
	}

}
