package edu.westga.cs6311.interest.model;

/**
 * Models a banking account that accrues simple interest that is compounded
 * monthly
 * 
 * @author CS6311
 * @version Fall 2023
 * 
 *          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *          ~~ DO NOT MODIFY THE CONTENTS OF THIS FILE AT ALL ~~
 *          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 */
public class Account {
	private double balance;
	private double rate;

	/**
	 * Constructor used to initialize the Account object
	 * 
	 * @param balance The initial balance
	 * @param rate    The interest rate between 0 (0%) and 1 (100%)
	 */
	public Account(double balance, double rate) {
		if (balance < 0) {
			balance = 0;
		}
		if (rate < 0 || rate > 1) {
			rate = 0;
		}
		this.balance = balance;
		this.rate = rate;
	}

	/**
	 * This method will be used to compound the interest at the end of a month
	 */
	public void endOfMonth() {
		this.balance += this.balance * this.rate / 12;
	}

	/**
	 * Returns the projected balance at the given month and year
	 * 
	 * @param yearNumber  The year we are interested in
	 * @param monthNumber The month we are interested in
	 * @return The projected balance, formatted to 2 decimal places
	 */
	public String getBalance(int yearNumber, int monthNumber) {
		double result = this.balance * Math.pow((1.0 + this.rate / 12.0), (yearNumber - 1) * 12 + monthNumber);
		return String.format("%.2f", result);
	}
}
