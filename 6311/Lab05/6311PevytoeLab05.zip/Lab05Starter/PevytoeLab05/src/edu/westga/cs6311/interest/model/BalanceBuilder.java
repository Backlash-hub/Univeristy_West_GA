package edu.westga.cs6311.interest.model;

/**
 * BalanceBuilder build a String that represents a table of 
 * 	monthly savings account balances over a period of years.
 * 	If the number of years is set with a valid value (between
 * 	1 and 10 years), the table will be built based on that value;
 * 	otherwise it will be built for the default number of years
 *
 * @author William Pevytoe
 *
 * @version 10/04/23
 */
public class BalanceBuilder {
	/**
	 * The default number of years for the table
	 */
	public static final int DEFAULT_YEARS = 10;
	private int years;
	private String theResults;
	private Account theAccount;
	
	/**
	 * Builds a new BalanceBuilder object to build a table of 
	 * 	monthly savings account balances for DEFAULT_YEARS (10)
	 */
	public BalanceBuilder() {
		this.years = DEFAULT_YEARS;
		this.theResults = "";
		this.theAccount = null;
	}
	
	/**
	 * Returns the number of years for this table
	 * 
	 * @return	The number of years for this table
	 */
	public int getYears() {
		return this.years;
	}
	
	/**
	 * Resets the number of years for the results to the specified value
	 * 
	 * @param			years	The number of years desired for these results
	 * @precondition	0 < years <= 10, otherwise years = DEFAULT_YEARS
	 */
	public void setYears(int years) {
		if (0 < years && years <= 10) {
			this.years = years;
		} else {
				years = DEFAULT_YEARS;
			}
		}

	/**
	 * Sets the Account for this set of results
	 * @param	theAccount	The Account to be used for these results
	 */
	public void setAccount(Account theAccount) {
		this.theAccount = theAccount;
	}
	
	/**
	 * Builds the results table for getYears() years
	 */
	public void buildTable() {
		this.buildHeading();
		this.buildYears();

	}
	
	/**
	 * Returns a String containing the results table for getYears() years
	 * 
	 * @return	The full table
	 */
	public String getResults() {
		return this.theResults;
	}
	
	/**
	 * Creates the top portion of the table
	 * Months 1-12 (X axis)
	 */
	private void buildHeading() {
		String theHeading = "\t";
		int monthNumber = 1;
		while (monthNumber <= 12) {
			theHeading += monthNumber + "\t";
			monthNumber++;
		}
		this.theResults = theHeading + "\n\n";
	}
	
	/**
	 * Creates the number of years on the left vertical side
	 * Number of years (Y axis)
	 */
	private void buildYears() {
		int yearNumber = 1;
		while (yearNumber <= this.getYears()) {
			this.theResults += this.buildNextYear(yearNumber);
			yearNumber++;
		}
	}
	
	/**
	 * Creates the data for table
	 * @param yearNumber the number of years (1-10) that the table will show
	 * @return the data for the table
	 */
	private String buildNextYear(int yearNumber) {
		String theYear = yearNumber + ":\t";
		int monthNumber = 1;
		while (monthNumber <= 12) {
			theYear += this.theAccount.getBalance(yearNumber, monthNumber) + "\t";
			monthNumber++;
		}
		return theYear + "\n";
	}
}
