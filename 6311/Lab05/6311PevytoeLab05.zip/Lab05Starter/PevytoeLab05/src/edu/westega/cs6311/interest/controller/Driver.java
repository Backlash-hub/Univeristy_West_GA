package edu.westega.cs6311.interest.controller;

import edu.westga.cs6311.interest.view.InterestView;

/**
 * Driver for the Balance Builder exercise
 * 
 * @author CS6311
 * @version Fall 2023
 * 
 *          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *          ~~ DO NOT MODIFY THE CONTENTS OF THIS FILE AT ALL ~~
 *          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 */
public class Driver {

	/**
	 * Entry-point into the application
	 * 
	 * @param args	not used
	 */
	public static void main(String[] args) {
		InterestView theView = new InterestView();
		theView.run();
	}

}
