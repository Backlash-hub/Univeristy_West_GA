package edu.westga.cs6311.matrixmath.model;

/**
 * The back end to create the Matrix/2D array
 * 
 * @author William Pevytoe
 * 
 * @version 10/18/23
 */
public class Matrix {
	private int[][] theMatrix;

	/**
	 * Constructor to initialize the 2D array with one parameter
	 * 
	 * @param newMatrix is the data within the 2D array
	 */
	public Matrix(int[][] newMatrix) {
		this.theMatrix = newMatrix;
	}
	
	/**
	 * This will return the table with the data
	 * 
	 * @return the table to a string value
	 */
	public String getTable() {
		StringBuilder result = new StringBuilder();
		for (int[] row : this.theMatrix) {
			for (int value : row) {
				result.append(value).append("\t");
				}
			result.append("\n");
			}
		return result.toString();
	}
		
	/**
	 * Gets the number of Rows
	 * 
	 * @return the number of Rows
	 */
	public int getNumberOfRows() {
		int rows = this.theMatrix.length;
		return rows;
	}
	
	/**
	 * Gets the number of Columns
	 * 
	 * @return the number of Columns
	 */
	public int getNumberOfColumns() {
		int columns = this.theMatrix[0].length;
		return columns;
	}
	
	/**
	 * Gets the value of a particular cell within the array
	 * 
	 * @param row : what row the data is in
	 * @param column : what column the data is in
	 * @return the value of the corresponding cell
	 */
	public int getValue(int row, int column) {
		int value = this.theMatrix[row][column];
		return value;
	}
	
	/**
	 * Adding one matrix to another
	 * 
	 * @param otherMatrix the second matrix
	 * @return the new matrix after adding the two together
	 */
	public Matrix addMatrix(Matrix otherMatrix) {
		int totalRows = this.getNumberOfRows();
		int totalColumns = this.getNumberOfColumns();
		int[][] results = new int[totalRows][totalColumns];
		for (int numberRow = 0; numberRow < totalRows; numberRow++) {
			for (int numberCol = 0; numberCol < totalColumns; numberCol++) {
				results[numberRow][numberCol] = this.theMatrix[numberRow][numberCol] + otherMatrix.getValue(numberRow, numberCol);
			}
		}
		return new Matrix(results);
	}
           
	/**
	 *  Interchanging its rows into columns or columns into rows
	 * 
	 * @return the original matrix in a transposed state
	 */
	public Matrix transposeMatrix() {
		int[][] tranMatrix = new int [this.theMatrix[0].length] [this.theMatrix.length];
		for (int numberRow = 0; numberRow < this.theMatrix.length; numberRow++) {
			for (int numberCol = 0; numberCol < this.theMatrix[0].length; numberCol++) {
				tranMatrix[numberCol][numberRow] = this.theMatrix[numberRow][numberCol];
	            }
	        }
		return new Matrix(tranMatrix);
	}
}
