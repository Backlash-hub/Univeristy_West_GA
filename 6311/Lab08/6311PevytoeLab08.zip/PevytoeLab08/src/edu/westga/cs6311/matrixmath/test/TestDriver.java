package edu.westga.cs6311.matrixmath.test;

/**
 * Running the TestMatrix
 * 
 * @author William Pevytoe
 * 
 * @version 10/18/23
 * 
 */

public class TestDriver {

	/**
	 * Running the TestMatrix
	 * 
	 * @param args not used
	 */
	public static void main(String[] args) {
		TestMatrix demo1 = new TestMatrix();
		demo1.runTests();
	}

}
