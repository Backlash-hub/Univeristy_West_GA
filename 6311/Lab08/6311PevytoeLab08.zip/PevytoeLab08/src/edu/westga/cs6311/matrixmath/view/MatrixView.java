package edu.westga.cs6311.matrixmath.view;

import java.util.Scanner;

import edu.westga.cs6311.matrixmath.model.Matrix;

/**
 *Takes user input to create the Matrix
 *
 * @author William Pevytoe
 * 
 * @version 10/21/23
 */
public class MatrixView {
	private Scanner input;
	private Matrix theMatrix;
	private int rows;
	
	/**
	 * Initialize the scanner and the Matrix with a value of null
	 */
	public MatrixView() {
		this.input = new Scanner(System.in);
		this.rows = 0;
		this.theMatrix = new Matrix(null);
	}
	
	/**
	 * Takes the User inputs to run the matrix
	 */
	public void run() {
		System.out.println("ENTERING THE MATRIX");
		System.out.println("");
		this.theMatrix = this.createMatrix();	
		int userValue = 0;
		while (userValue != 4) {
			userValue = this.userSelectTask();
			if (userValue == 1) {
				System.out.println(this.theMatrix.getTable());
			} else if (userValue == 2) {
				System.out.println(this.theMatrix.transposeMatrix().getTable());		
			} else if (userValue == 3) {
				Matrix matrixToAdd = this.createMatrix();
				System.out.println(this.theMatrix.addMatrix(matrixToAdd).getTable());			
			} else if (userValue == 4) {
				System.out.println("Goodbye");
				System.exit(0);
			}
		}		
	}
	
	/**
	 * Takes the user inputs to create a matrix
	 * 
	 * @return a matrix with the user inputs
	 */
	public Matrix createMatrix() {
		if (this.rows == 0) {
			System.out.println("Enter the number of rows: ");
			this.rows = Integer.parseInt(this.input.nextLine());			
		}
		int columns = 0;
		int[][] matrix = new int[this.rows][];
		for (int number = 0; number < this.rows; number++) {
			System.out.println("Enter the values in row " + (number + 1) + " with each value separated by a single blank space: ");
			String theRowInputs = this.input.nextLine();
			String[] columnValues = theRowInputs.split(" ");
			if (columns == 0) {
				columns = columnValues.length;
				matrix = new int [this.rows][columns];	
			}
			for (int position = 0; position < columns; position++) {
				matrix[number][position] = Integer.parseInt(columnValues[position]);			
			}
			
		}
		Matrix userMatrix = new Matrix(matrix);
		return userMatrix;
	}
	
	/**
	 * Asking User what they want to do with their original matrix
	 * 
	 * @return the users input as an int
	 */
	public int userSelectTask() {
		System.out.println("1 - View the matrix");
		System.out.println("2 - View the transposed matrix");
		System.out.println("3 - Add another matrix to original matrix");
		System.out.println("4 - Quit");
		System.out.println("Please enter your choise: ");
		return Integer.parseInt(this.input.nextLine());
	}

}
