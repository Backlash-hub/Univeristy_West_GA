package edu.westga.cs6311.matrixmath.controller;

import edu.westga.cs6311.matrixmath.view.MatrixView;

/**
 * Running the MatrixView
 * 
 *  @author William Pevytoe
 *  
 *  @version 10/22/23
 */

public class MatrixDriver {

	/**
	 * Running the MatrixView
	 * 
	 * @param args not used 
	 */
	public static void main(String[] args) {
		MatrixView interactive = new MatrixView();
		interactive.run();

	}

}
