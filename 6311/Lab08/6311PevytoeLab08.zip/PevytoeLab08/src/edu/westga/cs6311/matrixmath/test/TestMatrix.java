package edu.westga.cs6311.matrixmath.test;

import edu.westga.cs6311.matrixmath.model.Matrix;

/**
 * Testing the Matrix methods
 * 
 * @author William Pevytoe
 * 
 * @version 10/22/23
 * 
 */
public class TestMatrix {
	private Matrix theTable; 
	
	/**
	 * Constructing the test data and the matrix
	 */
	public TestMatrix() {
		int[][] data = {
				{1, 2, 3},
				{4, 5, 6},
				{7, 8, 9},
				{10, 11, 12}				
		};
		this.theTable = new Matrix(data);
	}
		
	/**
	 * The method that runs
	 * all the tests below
	 */
	public void runTests() {
		System.out.println("Check if the table is created");
		this.checkMatrixIsCreated(this.theTable);
		this.checkNumberOfRows();
		this.checkNumberOfColumns();
		this.checkValues(2, 3);
		this.checkSecondMatrix();
		this.checkTransposedMatrix();
	}
		
	/**
	 * Makes sure that the array was created
	 * 
	 * @param testTable is a matrix
	 */
	public void checkMatrixIsCreated(Matrix testTable) {
		if (testTable == null) {
			System.out.println("The table was not created");
		} else {
			System.out.println("The matrix:\n" + testTable.getTable());
			System.out.println("");	
		}
		
	}
	
	/**
	 * Checks the getNumberOfRows method
	 */
	public void checkNumberOfRows() {
		System.out.println("Checking number of Rows");
		System.out.println("Expected:\t" + 4);
		System.out.println("Actual:\t\t" + this.theTable.getNumberOfRows());
		System.out.println("");		
	}
	
	/**
	 * Checks the .getNumberOfColumns method
	 */
	public void checkNumberOfColumns() {
		System.out.println("Checking number of Columns");
		System.out.println("Expected:\t" + 3);
		System.out.println("Actual:\t\t" + this.theTable.getNumberOfColumns());
		System.out.println("");		
	}
	
	/**
	 * Checks that .getValue method is correct
	 * 
	 * @param row : what row the data is in
	 * @param column : what column the data is in
	 */
	public void checkValues(int row, int column) {
		System.out.println("Checking the value of row 2, column 2");
		System.out.println("Expected:\t" + 9);
		System.out.println("Actual:\t\t" + this.theTable.getValue(2, 2));
		System.out.println("");	
	}
	
	/**
	 * Checks that the .addMatrix method works
	 */
	public void checkSecondMatrix() {
		Matrix anotherMatrix = this.theTable.addMatrix(this.theTable);
		System.out.println("Adding the original matrix to itself");
		System.out.println("Expected:\n" + 2 + "\t" + 4 + "\t" + 6 + "\n"
				+ 8 + "\t" + 10 + "\t" + 12 + "\n"
				+ 14 + "\t" + 16 + "\t" + 18 + "\n"
				+ 20 + "\t" + 22 + "\t" + 24);
		System.out.println("");		 
		System.out.println("Actual:\n" + anotherMatrix.getTable());
		System.out.println("");
	}
	
	/**
	 * Checks the .transposeMatrix method
	 */
	public void checkTransposedMatrix() {
		Matrix newMatrix = this.theTable.transposeMatrix();
		System.out.println("Checking transposing method");
		System.out.println("The original Matrix:\n" + this.theTable.getTable());
		System.out.println("");
		System.out.println("The original Matrix transposed:\n" + newMatrix.getTable());	
	}
}
